from pathlib import Path
import os
import configparser
import numpy as np
import pandas as pd

DEM_STYLING = (Path(__file__).parents[1] / "stylings" / "dem.qml").as_posix()
LANDUSE_STYLING = (Path(__file__).parents[1] / "stylings" / "landuse.qml").as_posix()
SOIL_HYSOGS_STYLING = (Path(__file__).parents[1] / "stylings" / "soil_hysogs.qml").as_posix()
BOUNDS_STYLING = (Path(__file__).parents[1] / "stylings" / "bounds.qml").as_posix()
STREAMS_STYLING = (Path(__file__).parents[1] / "stylings" / "streams.qml").as_posix()
WATERSHED_STYLING = (
    Path(__file__).parents[1] / "stylings" / "watersheds.qml"
).as_posix()
POUR_POINT_STYLING = (
    Path(__file__).parents[1] / "stylings" / "pour_points.qml"
).as_posix()


class ShedProject:
    def __init__(self, name, folder_location, layer_manager):
        self.name = name
        self.folder_location = folder_location
        self.config_location = Path(self.folder_location) / self.name / "config.ini"
        self.layer_manager = layer_manager
        self.config = configparser.ConfigParser(allow_no_value=True)
        self.check_if_exists()

    @property
    def project_dir(self) -> Path:
        self.config.read(self.config_location)
        return Path(self.config.get("PATHS", "project_dir", fallback=None))

    @property
    def data_dir(self) -> Path:
        self.config.read(self.config_location)
        return Path(self.config.get("PATHS", "data_dir", fallback=None))

    @property
    def dem_dir(self) -> Path:
        self.config.read(self.config_location)
        return Path(self.config.get("PATHS", "dem_dir", fallback=None))

    @property
    def landuse_dir(self) -> Path:
        self.config.read(self.config_location)
        return Path(self.config.get("PATHS", "landuse_dir", fallback=None))
    
    @property
    def soil_dir(self) -> Path:
        self.config.read(self.config_location)
        return Path(self.config.get("PATHS", "soil_dir", fallback=None))

    @property
    def aux_dir(self) -> Path:
        self.config.read(self.config_location)
        return Path(self.config.get("PATHS", "aux_dir", fallback=None))
    
    @property
    def watershed_dir(self) -> Path:
        self.config.read(self.config_location)
        return Path(self.config.get("PATHS", "watershed_dir", fallback=None))

    @property
    def crs(self) -> str:
        self.config.read(self.config_location)
        return self.config.get("SETTINGS", "crs", fallback=None)

    @property
    def shapefile_location(self) -> Path:
        self.config.read(self.config_location)
        return Path(self.config.get("SHAPE", "shapefile_path", fallback=None))
  
    @property
    def shape_wkt(self):
        self.config.read(self.config_location)
        return self.config.get("SHAPE", "shapefile_wkt", fallback=None)
    
    @property
    def shape_wkt_wgs84(self):
        self.config.read(self.config_location)
        return self.config.get("SHAPE", "shapefile_wkt_wgs84", fallback=None)
      
    @property 
    def osm_output_location(self) -> Path:
        return self.landuse_dir / "OSM"
        
    @property
    def dem_file_location(self) -> Path:
        self.config.read(self.config_location)
        if not pd.isnull(self.config.get("FILENAMES", "dem_filename", fallback=None)):
            return self.dem_dir / self.config.get(
                "FILENAMES", "dem_filename", fallback=None
            )

    @property
    def filled_dem_file_location(self) -> Path:
        self.config.read(self.config_location)
        if not pd.isnull(self.config.get("FILENAMES", "filled_dem_filename", fallback=None)):
            return self.dem_dir / self.config.get(
                "FILENAMES", "filled_dem_filename", fallback=None
            )

    @property
    def flow_accumulation_file_location(self) -> Path:
        self.config.read(self.config_location)
        if not pd.isnull(self.config.get("FILENAMES", "flow_accumulation_filename", fallback=None)):
            return self.dem_dir / self.config.get(
                "FILENAMES", "flow_accumulation_filename", fallback=None
            )

    @property
    def stream_network_file_location(self) -> Path:
        self.config.read(self.config_location)
        if not pd.isnull(self.config.get("FILENAMES", "stream_network_filename", fallback=None)):
            return self.dem_dir / self.config.get(
                "FILENAMES", "stream_network_filename", fallback=None
            )

    @property
    def d8_pointer_file_location(self):
        self.config.read(self.config_location)
        if not pd.isnull(self.config.get("FILENAMES", "d8_pointer_filename", fallback=None)):
            return self.dem_dir / self.config.get(
                "FILENAMES", "d8_pointer_filename", fallback=None
            )

    @property
    def landuse_file_location(self):
        self.config.read(self.config_location)
        if not pd.isnull(self.config.get("FILENAMES", "landuse_filename", fallback=None)):
            return self.landuse_dir / self.config.get(
                "FILENAMES", "landuse_filename", fallback=None
            )
    
    @property
    def soil_file_location(self):
        self.config.read(self.config_location)
        if not pd.isnull(self.config.get("FILENAMES", "soil_filename", fallback=None)):
            return self.soil_dir / self.config.get(
                "FILENAMES", "soil_filename", fallback=None
            )
            
    def check_if_exists(self):
        if os.path.exists(Path(self.folder_location) / self.name):
            self.restore_setup()
        else:
            self.initial_setup()

    def initial_setup(self):
        # create project dir
        os.makedirs(self.config_location.parents[0], exist_ok=True)

        self.create_config()

        for dirs in [self.data_dir, self.dem_dir, self.landuse_dir, self.watershed_dir, self.aux_dir, self.osm_output_location]:
            os.makedirs(dirs, exist_ok=True)

    def restore_setup(self):
        # add layers to map
        if self.shapefile_location not in [None, ""]:
            self.layer_manager.add_vector_layer_to_group(
                file_location=self.shapefile_location.as_posix(),
                title="Bounds",
                styling_file=BOUNDS_STYLING,
            )

        if self.landuse_file_location not in [None, ""]:
            lu_resolution = 10
            lu_version = f"v{self.landuse_file_location.stem.split(' v')[-1]}"
                    
            self.layer_manager.add_raster_layer_to_group(
                file_location=self.landuse_file_location.as_posix(),
                title=f"ESA WorldCover - {lu_resolution}m - {lu_version}",
                styling_file=LANDUSE_STYLING,
                insert_pos=1,
            )
            
        if self.soil_file_location not in [None, ""]:
            hysogs_resolution = 250
  
            self.layer_manager.add_raster_layer_to_group(
                file_location=self.soil_file_location.as_posix(),
                title=f"HySOGS - {hysogs_resolution}m ",
                styling_file=SOIL_HYSOGS_STYLING,
                insert_pos=1,
            )

        if self.dem_file_location not in [None, ""]:
            dem_resolution = self.dem_file_location.stem.split("-")[2]
            dem_version = self.dem_file_location.stem.split("-")[3]
                    
            self.layer_manager.add_raster_layer_to_group(
                file_location=self.dem_file_location.as_posix(),
                title=f"Copernicus DEM - {dem_resolution}m - {dem_version}",
                styling_file=DEM_STYLING,
                insert_pos=1,
            )

        watershed_path = Path(self.watershed_dir) / f"watershed_{id}.gpkg"
        pour_point_path = Path(self.watershed_dir) / f"pour_point_{id}.gpkg"
        
        if watershed_path.exists():
            self.layer_manager.add_vector_layer_to_group(
                file_location=watershed_path.as_posix(),
                title=f"Watersheds",
                styling_file=WATERSHED_STYLING,
                insert_pos=1,
            )
        
        if pour_point_path.exists():
            self.layer_manager.add_vector_layer_to_group(
                file_location=pour_point_path.as_posix(),
                title=f"Pour Points",
                styling_file=POUR_POINT_STYLING,
                insert_pos=1,
            )

    def read_config(self):
        config = configparser.ConfigParser(allow_no_value=True)
        config.read(self.project_dir / "config.ini")
        # self.shapefile_path = config.get('SHAPE', 'shapefile_path')

    def create_config(self):
        # create project config
        config = configparser.ConfigParser(allow_no_value=True)
        config["PATHS"] = {
            "project_dir": Path(self.folder_location) / self.name,
            "data_dir": Path(self.folder_location) / self.name / "data",
            "dem_dir": Path(self.folder_location) / self.name / "data" / "dem",
            "landuse_dir": Path(self.folder_location) / self.name / "data" / "landuse",
            "aux_dir": Path(self.folder_location) / self.name / "data" / "misc",
            "soil_dir": Path(self.folder_location) / self.name / "data" / "soil",
            "watershed_dir": Path(self.folder_location)
            / self.name
            / "data"
            / "watershed",
        }

        config["FILENAMES"] = {
            "dem_filename": None,
            "filled_dem_filename": None,
            "flow_accumulation_filename": None,
            "d8_pointer_filename": None,
            "landuse_filename": None,
            "soil_filename": None,
            "stream_network_filename": None,
        }
        config["SHAPE"] = {"shapefile_path": None}
        config["SETTINGS"] = {"crs": None}
        
        config.write(open(self.config_location, "w"))

    def update_config(self, category, parameter, value):
        config = configparser.ConfigParser(allow_no_value=True)
        config.read(self.config_location)
        config.set(category, parameter, value)

        with open(self.config_location, "w") as configfile:
            config.write(configfile)
