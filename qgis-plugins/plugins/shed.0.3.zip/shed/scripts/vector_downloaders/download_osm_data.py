import osmnx as ox
from pathlib import Path

import geopandas as gpd


def download_osm_data(request_geom, output_folder):
    osm_landuse = ox.features.features_from_polygon(
        polygon=request_geom, tags={"landuse": True}
    )
    osm_landuse = osm_landuse.loc[osm_landuse.geometry.geom_type == "Polygon"]

    osm_buildings = ox.features.features_from_polygon(
        polygon=request_geom, tags={"building": True}
    )
    osm_buildings = osm_buildings[["amenity", "name", "geometry"]]
    osm_buildings = osm_buildings.loc[osm_buildings.geometry.geom_type == "Polygon"]

    osm_roads = ox.features.features_from_polygon(
        polygon=request_geom, tags={"highway": True}
    )
    
    osm_roads = osm_roads.loc[osm_roads.geometry.geom_type == "LineString"]
    osm_roads = osm_roads[["name", "highway", "surface", "geometry"]]

    osm_landuse.to_file(output_folder / "OSM Landuse.gpkg")
    osm_buildings.to_file(output_folder / "OSM Buildings.gpkg")
    osm_roads.to_file(output_folder / "OSM Roads.gpkg")