from qgis.gui import (
    QgsRubberBand,
    QgsVertexMarker,
    QgsHighlight,
)
from PyQt5.QtGui import QColor, QToolButton
from PyQt5.QtWidgets import QMessageBox
from qgis.core import (
    QgsGeometry,
    QgsPointXY,
    QgsMesh,
    QgsLineString,
)
from qgis.gui import (
    QgsMapTool,
)
from qgis.core import (
    QgsPointXY,
)
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.utils import iface


class PointSampler(QgsMapTool):
    mapClick = pyqtSignal(QgsPointXY, bool)

    def __init__(self, canvas):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas

    def canvasPressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.mapClick.emit(e.mapPoint(), False)
        if e.button() == Qt.RightButton:
            self.mapClick.emit(e.mapPoint(), True)


class SampleUpstreamWatershedTool(QToolButton):
    geometryUpdated = pyqtSignal(QgsPointXY)

    def __init__(self, parent=None):
        QToolButton.__init__(self, parent)
        self.setToolTip(
            "Select pour point on map to delineate upstream watershed (right click to confirm)"
        )

        self.setText("Delineate Upstream Watershed")
        self.setCheckable(True)

        self.clicked.connect(self.toolbutton_clicked)

        self.mesh_geometries = {}

        self.canvas = iface.mapCanvas()
        self.clicked_point = None
        self.map_tool = PointSampler(canvas=iface.mapCanvas())
        self.map_tool.mapClick.connect(self.on_mapclick)
        self.map_tool.setButton(self)

    def clear_canvas(self):
        marker_items = [
            i
            for i in self.canvas.scene().items()
            if issubclass(type(i), QgsRubberBand)
            or issubclass(type(i), QgsVertexMarker)
            or issubclass(type(i), QgsHighlight)
        ]

        for marker in marker_items:
            if marker in self.canvas.scene().items():
                self.canvas.scene().removeItem(marker)

    def on_mapclick(self, point, clear):
        if clear:
            reply = QMessageBox.question(
                self,
                "Delineate Watershed",
                "Confirm this point",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )

            if reply == QMessageBox.Yes:
                self.geometryUpdated.emit(point)
            else:
                self.clicked_point = None
                self.clear_canvas()

        else:
            self.clicked_point = point
            self.display_point_on_map()

    def display_point_on_map(self):
        """
        This function takes the clicked point and plots a marker
        """
        self.clear_canvas()

        edge_marker = QgsVertexMarker(self.canvas)
        edge_marker.setCenter(self.clicked_point)
        edge_marker.setColor(QColor(255, 0, 0))  # (R,G,B)
        edge_marker.setIconSize(10)
        edge_marker.setIconType(QgsVertexMarker.ICON_X)
        edge_marker.setPenWidth(3)
        edge_marker.show()

    def activate_maptool(self):
        self.canvas.setMapTool(self.map_tool)

    def deactivate_maptool(self):
        self.clear_canvas()
        self.clicked_points = []
        self.canvas.unsetMapTool(self.map_tool)

    def toolbutton_clicked(self):
        if self.isChecked():
            self.activate_maptool()
        else:
            self.deactivate_maptool()
