import requests
import geopandas as gpd
from pathlib import Path
import sys
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)
sys.path.append(
    r"C:\Users\923265\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins"
)
from shed.scripts.utils.raster_utils.get_raster_crs import get_raster_crs
from shed.scripts.utils.raster_utils.crop_raster_on_shape import crop_raster_on_shape
from shed.scripts.utils.raster_utils.reproject_raster import reproject_raster


MESSAGE_CATEGORY = "RasterDownload"

class SessionWithHeaderRedirection(requests.Session):
    AUTH_HOST = "urs.earthdata.nasa.gov"

    def __init__(self, username, password):
        super().__init__()
        self.auth = (username, password)

    def rebuild_auth(self, prepared_request, response):
        headers = prepared_request.headers
        url = prepared_request.url

        if "Authorization" in headers:
            original_parsed = requests.utils.urlparse(response.request.url)
            redirect_parsed = requests.utils.urlparse(url)

            if (
                (original_parsed.hostname != redirect_parsed.hostname)
                and redirect_parsed.hostname != self.AUTH_HOST
                and original_parsed.hostname != self.AUTH_HOST
            ):
                del headers["Authorization"]
        return


class DownloadNasaEarthData:
    def __init__(self, shape, shape_wgs84, soil_dir, username, password, target_dir):
        self.username = username
        self.password = password
        self.cmrurl = "https://cmr.earthdata.nasa.gov/search/"
        self.target_dir = target_dir
        self.shape = shape
        self.shape_wgs84 = shape_wgs84
        self.soil_dir = soil_dir
        
        QgsMessageLog.logMessage(
                "{name} - Initiate HySOGS Downloader tool".format(
                    name=self.shape,
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )
        QgsMessageLog.logMessage(
                "{name} - Initiate HySOGS Downloader tool".format(
                    name=self.shape.geometry.iloc[0],
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

    def get_concept_id(self, doi):
        doisearch = self.cmrurl + "collections.json?doi=" + doi

        response = requests.get(doisearch)
        response.raise_for_status()
        concept_id = response.json()["feed"]["entry"][0]["id"]
        return concept_id

    def get_shape_bound(self):
        bound_str = ",".join(map(str, self.shape_wgs84.bounds.squeeze().tolist()))
        return bound_str

    def get_shape_geom(self, buffer=0):
        shape = self.shape_wgs84.copy()
        shape = shape.buffer(buffer)
        return shape.unary_union

    def get_download_url(self, doi):
        cmr_param = {
            "collection_concept_id": self.get_concept_id(doi=doi),
            "page_size": 2000,
            "page_num": 1,
            "bounding_box[]": self.get_shape_bound(),
        }
        granulesearch = self.cmrurl + "granules.json"

        response = requests.get(granulesearch, params=cmr_param)
        granules = response.json()["feed"]["entry"][0].get("links")

        download_url = [
            s["href"]
            for s in granules
            if "title" in s and s["title"] == "Download HYSOGs250m.tif"
        ][0]
        return download_url

    def download_and_process_raster(self, download_url: str):
        session = SessionWithHeaderRedirection(self.username, self.password)
        response = session.get(download_url, stream=True)

        response.raise_for_status()

        if not self.soil_dir.exists():
            self.soil_dir.mkdir()

        with open(self.soil_dir / "hysogs_250m.tif", "wb") as fd:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                fd.write(chunk)

        cropped_raster_path = crop_raster_on_shape(
            input_raster=self.soil_dir / "hysogs_250m.tif",
            geom=self.get_shape_geom(buffer=0.01),
        )
        return cropped_raster_path
