from PyQt5.QtCore import pyqtSignal
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)
from shed.scripts.raster_downloaders.download_esa_raster import DownloadWorldCover
from shed.scripts.utils.raster_utils.merge_and_reproject_rasters import (
    merge_and_reproject_rasters,
)
from shed.scripts.utils.raster_utils.crop_raster import (
    crop_raster,
)

import geopandas as gpd
from pathlib import Path
import shutil
import time

MESSAGE_CATEGORY = "RasterDownload"


class EsaWorldCoverDownloadTask(QgsTask):
    get_raster_path = pyqtSignal(str)
    isFinished = pyqtSignal(bool)

    def __init__(self, landuse_dir, shape_wkt, shape_wkt_wgs84, tiles_to_download, crs, esa_filename, description):
        super().__init__(description, QgsTask.CanCancel)
        self.total = 0
        self.exception = None
        self.landuse_dir = landuse_dir
        self.tiles_to_download = tiles_to_download
        self.crs = crs
        self.esa_filename = esa_filename
        self.shape = gpd.GeoSeries.from_wkt(
            [shape_wkt], crs=self.crs
        )
        self.shape_wgs84 = gpd.GeoSeries.from_wkt(
            [shape_wkt_wgs84], crs="epsg:4326"
        )
            
    def run(self):
        """Here you implement your heavy lifting.
        Should periodically test for isCanceled() to gracefully
        abort.
        This method MUST return True or False.
        Raising exceptions will crash QGIS, so we handle them
        internally and raise them in self.finished
        """
        try:
            # downloading
            QgsMessageLog.logMessage(
                "{name} - Initiate WorldCover Downloader tool".format(
                    name=self.description()
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )
   
            download_worldcover = DownloadWorldCover(
                target_folder=self.landuse_dir, shape=self.shape_wgs84
            )

            QgsMessageLog.logMessage(
                "{name} - Determining tiles to download".format(
                    name=self.description()
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            QgsMessageLog.logMessage(
                "{name} - Downloading WorldCover tiles".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            download_dir = download_worldcover.download_tiles(
                tiles_to_download=self.tiles_to_download
            )

            raster_paths = [f for f in Path(download_dir).glob("*") if f.suffix == ".tif"]
                            
            output_merged_raster = self.landuse_dir / "esa_temp.tif"
            
            QgsMessageLog.logMessage(
                "{name} - Merging and reprojecting...".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )
            
            merge_and_reproject_rasters(
                target_crs=int(self.crs.split(":")[-1]),
                raster_paths=raster_paths,
                output_filename=output_merged_raster,
                target_res=10,

            )
                 
            QgsMessageLog.logMessage(
                "{name} - Cropping raster on shape...".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )
            
            self.output_raster_path = (self.landuse_dir / self.esa_filename).as_posix()
            
            crop_raster(input_raster=output_merged_raster, output_raster=self.output_raster_path, clipping_shape=self.shape.geometry.iloc[0])
            
            output_merged_raster.unlink()
            return True

        except Exception as e:
            self.exception = e
            self.cancel()
            return False

    def finished(self, result):
        """
        This function is automatically called when the task has
        completed (successfully or not).
        You implement finished() to do whatever follow-up stuff
        should happen after the task is complete.
        finished is always called from the main thread, so it's safe
        to do GUI operations and raise Python exceptions here.
        result is the return value from self.run.
        """

        if result:
            self.get_raster_path.emit(self.output_raster_path)
            self.isFinished.emit(True)
            QgsMessageLog.logMessage(
                "{name} completed".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Success,
            )
        else:
            if self.exception is None:
                QgsMessageLog.logMessage(
                    "{name} not successful but without "
                    "exception (probably the task was manually "
                    "canceled by the user)".format(name=self.description()),
                    MESSAGE_CATEGORY,
                    Qgis.Warning,
                )
            else:
                QgsMessageLog.logMessage(
                    "{name} Exception: {exception}".format(
                        name=self.description(), exception=self.exception
                    ),
                    MESSAGE_CATEGORY,
                    Qgis.Critical,
                )
                raise self.exception

    def cancel(self):
        QgsMessageLog.logMessage(
            'RandomTask "{name}" was canceled'.format(name=self.description()),
            MESSAGE_CATEGORY,
            Qgis.Info,
        )
        super().cancel()
