from PyQt5.QtCore import pyqtSignal
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)
from qgis.core import QgsMessageLog
from shed.scripts.raster_downloaders.download_hysogs_raster import (
    DownloadNasaEarthData,
)
from shed.scripts.utils.raster_utils.get_raster_crs import get_raster_crs
from shed.scripts.utils.raster_utils.merge_and_reproject_rasters import (
    merge_and_reproject_rasters,
)
from shed.scripts.utils.raster_utils.reproject_raster import reproject_raster
from shed.scripts.utils.raster_utils.crop_raster import (
    crop_raster,
)
from pathlib import Path
import geopandas as gpd

MESSAGE_CATEGORY = "RasterDownload"


class HysogsSoilDownloadTask(QgsTask):
    get_raster_path = pyqtSignal(Path)
    isFinished = pyqtSignal(bool)

    def __init__(
        self,
        soil_dir,
        shape_wkt,
        shape_wkt_wgs84,
        crs,
        spatial_res,
        description,
        soil_filename,
        credentials,
    ):
        super().__init__(description, QgsTask.CanCancel)
        self.total = 0
        self.exception = None
        self.crs = crs
        self.soil_dir = soil_dir
        self.spatial_res = spatial_res
        self.soil_filename = soil_filename
        self.credentials = credentials

        self.shape = gpd.GeoSeries.from_wkt([shape_wkt], crs=self.crs)
        self.shape_wgs84 = gpd.GeoSeries.from_wkt([shape_wkt_wgs84], crs="epsg:4326")

    def run(self):
        """Here you implement your heavy lifting.
        Should periodically test for isCanceled() to gracefully
        abort.
        This method MUST return True or False.
        Raising exceptions will crash QGIS, so we handle them
        internally and raise them in self.finished
        """
        try:
            QgsMessageLog.logMessage(
                "{name} - Initiate HySOGS Downloader tool".format(
                    name=self.description()
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            earth_data = DownloadNasaEarthData(
                shape=self.shape,
                shape_wgs84=self.shape_wgs84,
                soil_dir=self.soil_dir,
                username=self.credentials.get("username"),
                password=self.credentials.get("password"),
                target_dir=self.soil_dir,
            )

            download_url = earth_data.get_download_url(
                doi="10.3334/ORNLDAAC/1566",
            )

            QgsMessageLog.logMessage(
                "{name} - Downloading rasters".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )
            hysogs_raster_path = earth_data.download_and_process_raster(
                download_url=download_url,
            )

            QgsMessageLog.logMessage(
                "{name} - Reprojecting...".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            hysogs_reprojected_path = (
                hysogs_raster_path.parent / f"{hysogs_raster_path.stem}_reprojected.tif"
            )
            reproject_raster(
                target_crs=int(self.crs.split(":")[-1]),
                input_raster_path=hysogs_raster_path,
                output_raster_path=hysogs_reprojected_path,
                target_res=250,
            )

            QgsMessageLog.logMessage(
                "{name} - Cropping raster on shape".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            self.output_raster_path = self.soil_dir / "HySOGS.tif"

            QgsMessageLog.logMessage(
                "{name} - Cropping raster on shape - path: {p}".format(
                    name=self.description(), p=hysogs_reprojected_path
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            crop_raster(
                input_raster=hysogs_reprojected_path,
                output_raster=self.output_raster_path,
                clipping_shape=self.shape.geometry.iloc[0],
            )

            return True

        except Exception as e:
            self.exception = e
            self.cancel()
            return False

    def finished(self, result):
        """
        This function is automatically called when the task has
        completed (successfully or not).
        You implement finished() to do whatever follow-up stuff
        should happen after the task is complete.
        finished is always called from the main thread, so it's safe
        to do GUI operations and raise Python exceptions here.
        result is the return value from self.run.
        """

        if result:
            self.get_raster_path.emit(self.output_raster_path)
            self.isFinished.emit(True)
            QgsMessageLog.logMessage(
                "{name} completed".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Success,
            )
        else:
            if self.exception is None:
                QgsMessageLog.logMessage(
                    "{name} not successful but without "
                    "exception (probably the task was manually "
                    "canceled by the user)".format(name=self.description()),
                    MESSAGE_CATEGORY,
                    Qgis.Warning,
                )
            else:
                QgsMessageLog.logMessage(
                    "{name} Exception: {exception}".format(
                        name=self.description(), exception=self.exception
                    ),
                    MESSAGE_CATEGORY,
                    Qgis.Critical,
                )
                raise self.exception

    def cancel(self):
        QgsMessageLog.logMessage(
            'RandomTask "{name}" was canceled'.format(name=self.description()),
            MESSAGE_CATEGORY,
            Qgis.Info,
        )
        super().cancel()
