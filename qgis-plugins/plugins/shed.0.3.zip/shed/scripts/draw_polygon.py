from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.core import QgsGeometry, QgsProject, QgsMeshDatasetIndex, QgsPoint, QgsPointXY, QgsWkbTypes, QgsCoordinateReferenceSystem, QgsMessageLog, Qgis
from qgis.gui import *
from qgis.utils import iface

from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.core import QgsWkbTypes
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QKeySequence, QColor

# stolen from https://github.com/Open-EO/openeo-qgis-plugin/blob/master/drawPoly.py
MESSAGE_CATEGORY = 'DrawPolygon'

class DrawPolygon(QgsMapTool):
    """
    This class is responsible for drawing a polygon on the map and returning the coordinates of it.
    """
    selectionDone = pyqtSignal()
    move = pyqtSignal()
    selectedPoly = pyqtSignal('QgsGeometry')
    selectedCRS = pyqtSignal('QgsCoordinateReferenceSystem')
    def __init__(self, canvas):
        """
        Initialize the draw polygon class
        """
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.status = 0
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rb.setColor(QColor(255, 0, 0, 63))   

    def keyPressEvent(self, e):
        """
        Called if a keyboard key got pressed
        :param e: Event
        """
        if e.matches(QKeySequence.Undo):
            if self.rb.numberOfVertices() > 1:
                self.rb.removeLastPoint()

    def canvasPressEvent(self, e):
        """
        Called if a mouse button got pressed on the map canvas.
        :param e: Event
        """
        if e.button() == Qt.LeftButton:
            if self.status == 0:
                self.rb.reset(QgsWkbTypes.PolygonGeometry)
                self.status = 1
            self.rb.addPoint(self.toMapCoordinates(e.pos()))
        else:
            QgsMessageLog.logMessage(
                    'DrawPolygon - canvasPressEvent - NotLeftButton',
                    MESSAGE_CATEGORY, Qgis.Info)
            if self.rb.numberOfVertices() > 2:
                QgsMessageLog.logMessage(
                    'DrawPolygon - canvasPressEvent - NotLeftButton - vertices > 2',
                    MESSAGE_CATEGORY, Qgis.Info)
                self.status = 0
                self.rb.closePoints(doUpdate=True)
                self.selectionDone.emit()
                self.selectedPoly.emit(self.rb.asGeometry())
                self.selectedCRS.emit(self.canvas.mapSettings().destinationCrs())
            else:
                self.reset()

    def canvasMoveEvent(self, e):
        """
        Called if a mouse button got pressed on the map canvas.
        :param e: Event
        """
       
        if self.rb.numberOfVertices() > 0 and self.status == 1:
            self.rb.removeLastPoint(0)
            self.rb.addPoint(self.toMapCoordinates(e.pos()))

    def reset(self):
        """
        Reseting the polygon
        """
        self.status = 0
        self.rb.reset()

    def deactivate(self):
        """
        Deactivate the polygon
        """
        self.rb.reset()
        QgsMapTool.deactivate(self)
   
        