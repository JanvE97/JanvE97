from osgeo import osr, ogr, gdal


def polygonize(raster_path, vector_path, layer_name="layer", epsg=32640):
    src_ds = gdal.Open(raster_path)
    #
    srcband = src_ds.GetRasterBand(1)

    drv = ogr.GetDriverByName("ESRI Shapefile")
    dst_ds = drv.CreateDataSource(vector_path)

    sp_ref = osr.SpatialReference()
    sp_ref.SetFromUserInput(f"EPSG:{epsg}")

    dst_layer = dst_ds.CreateLayer(layer_name, srs=sp_ref)

    fld = ogr.FieldDefn("value", ogr.OFTInteger)
    dst_layer.CreateField(fld)
    dst_field = dst_layer.GetLayerDefn().GetFieldIndex("value")

    gdal.Polygonize(srcband, None, dst_layer, dst_field, [], callback=None)