import rasterio
from rasterio.mask import mask
from pathlib import Path
from shapely.geometry import Polygon


def crop_raster_on_shape(input_raster: Path, geom: Polygon):
    with rasterio.open(input_raster) as src:
        out_image, out_transform = mask(src, [geom], crop=True)
        out_meta = src.meta

        out_meta.update(
            {
                "driver": "GTiff",
                "height": out_image.shape[1],
                "width": out_image.shape[2],
                "transform": out_transform,
            }
        )

        dst_path = input_raster.parent / f"{input_raster.stem}_clipped.tif"

        with rasterio.open(dst_path, "w", **out_meta) as dst:
            dst.write(out_image)

        return dst_path
