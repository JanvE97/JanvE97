import whitebox_workflows
from pathlib import Path
import pandas as pd


def create_flow_accumulation_raster(project):
    wbt = whitebox_workflows.WbEnvironment()
    wbt.verbose = False
    auto_compress = True
    
    if not pd.isnull(project.flow_accumulation_file_location) and project.flow_accumulation_file_location.exists():
        return True, "Flow accumulation file already exists"
    else:
        if not pd.isnull(project.filled_dem_file_location) and project.filled_dem_file_location.exists():
            filled_dem = wbt.read_raster(project.filled_dem_file_location.as_posix())
            d8_flowaccumulation = wbt.d8_flow_accum(filled_dem)
            
            flow_accum_name = f"{project.filled_dem_file_location.stem}_d8_flow_accum.tif"
            
            wbt.write_raster(
                d8_flowaccumulation,
                (project.dem_dir / flow_accum_name).as_posix(),
                compress=auto_compress,
            )
            
            project.update_config(
                category="FILENAMES",
                parameter="flow_accumulation_filename",
                value=(project.dem_dir / flow_accum_name).name,
            )
            return True, "Flow accumulation succesfully created"
        else:
            return False, "Filled DEM not found"
