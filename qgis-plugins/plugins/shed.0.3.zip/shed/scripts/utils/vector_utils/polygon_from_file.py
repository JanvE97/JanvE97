import geopandas as gpd
from qgis.gui import QgsRubberBand
from PyQt5.QtGui import QFileDialog


def load_polygon_from_file(project, layer_manager, canvas, bounds_styling):
    # write current canvas crs to config.ini
    project.update_config(
        category="SETTINGS",
        parameter="crs",
        value=str(canvas.mapSettings().destinationCrs().authid()),
    )

    # remove current polygons
    [
        i.reset()
        for i in canvas.scene().items()
        if issubclass(type(i), QgsRubberBand)
    ]

    # get filename
    polygon_file = QFileDialog.getOpenFileName(
        filter="Geopackage (*.gpkg);;ESRI Shapefile (.shp)"
    )[0]

    shape = gpd.read_file(polygon_file)
    if shape.crs != project.crs:
        shape = shape.to_crs(project.crs)
    shape.to_file(project.data_dir / "shape.gpkg")

    # update reference
    project.update_config(
        category="SHAPE",
        parameter="shapefile_path",
        value=(project.data_dir / "shape.gpkg").as_posix(),
    )

    # show geometry on map
    layer_manager.add_vector_layer_to_group(
        title="Bounds",
        file_location=(project.data_dir / "shape.gpkg").as_posix(),
        styling_file=bounds_styling,
    )