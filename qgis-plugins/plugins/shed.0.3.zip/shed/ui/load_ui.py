import os
from qgis.PyQt import QtGui, QtWidgets, uic

FORM_CLASS_RUN, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "table_view.ui")
)

class TableView(QtWidgets.QDialog, FORM_CLASS_RUN):
    def __init__(self, parent=None):
        """Constructor."""
        super(TableView, self).__init__(parent)
        self.setupUi(self)