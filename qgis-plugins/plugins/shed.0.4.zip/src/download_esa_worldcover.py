import geopandas as gpd
import requests
from pathlib import Path
import os
from requests.adapters import HTTPAdapter, Retry
from concurrent.futures import ThreadPoolExecutor
from shed.src.utils.postprocess_raster import (
    postprocess_raster,
)


class DownloadEsaWorldCover:
    def __init__(
        self,
        target_folder,
        shape,
        target_epsg,
        parallel_downloads: int = 6,
    ):
        self.amazon_s3_prefix = "https://esa-worldcover.s3.eu-central-1.amazonaws.com"
        self.shape = shape
        self.version = "v200"
        self.year = 2021
        self.target_folder = target_folder
        self.target_epsg = target_epsg

        self.download_dir = Path(self.target_folder) / "ESA_WorldCover"
        self.download_dir.mkdir(exist_ok=True, parents=True)

        self.parallel_downloads = parallel_downloads

    def esa_request(
        self,
        tile,
    ):
        url = f"{self.amazon_s3_prefix}/{self.version}/{self.year}/map/ESA_WorldCover_10m_{self.year}_{self.version}_{tile}_Map.tif"
        out_fn = (
            self.download_dir
            / f"{self.target_folder.stem}_{tile}_ESA_WorldCover_EPSG_4326.tif"
        )

        if not out_fn.exists():
            session = requests.Session()
            retries = Retry(
                total=5, backoff_factor=0.5, status_forcelist=[414, 500, 502, 503, 504]
            )
            session.mount("https://", HTTPAdapter(max_retries=retries))
            r = session.get(url, allow_redirects=True)

            with open(out_fn, "wb") as f:
                f.write(r.content)

    def download_tiles(self, tiles_to_download):
        # create download dir
        print(f"ESA WorldCover - Downloading {len(tiles_to_download)} tiles...")
        os.makedirs(self.download_dir, exist_ok=True)
        with open(Path(self.download_dir) / "landcover class.txt", "w") as f:
            f.writelines(
                [
                    "MapCode    LandCoverClass",
                    "\n10 Tree cover",
                    "\n20 Shrubland",
                    "\n30 Grassland",
                    "\n40 Cropland",
                    "\n50 Built-up",
                    "\n60 Bare/sparse vegetation",
                    "\n70 Snow and ice",
                    "\n80 Permanent water bodies",
                    "\n90 Herbaceous wetland",
                    "\n95 Mangroves",
                    "\n100    Moss and lichen",
                    "\nfor more information > https://worldcover2021.esa.int/data/docs/WorldCover_PUM_V2.0.pdf",
                ]
            )

        with ThreadPoolExecutor(max_workers=self.parallel_downloads) as executor:
            executor.map(self.esa_request, tiles_to_download)

        raster_files = list(self.download_dir.glob("*.tif"))

        output_path = (
            self.download_dir
            / f"{self.target_folder.stem}_ESA_WorldCover_EPSG_{self.target_epsg}.tif"
        )
        self.shape_dst_crs = self.shape.to_crs(epsg=self.target_epsg)

        final_wc = postprocess_raster(
            target_crs=self.target_epsg,
            raster_paths=raster_files,
            output_filename=output_path,
            clipping_polygon=self.shape_dst_crs.geometry.iloc[0],
            target_res=10,
            resample_algorithm="bilinear",
        )

        print("ESA WorldCover - Removing intermediary files...")
        [f.unlink() for f in self.download_dir.glob("*.tif") if f != final_wc]

        final_wc.rename(
            final_wc.parent / f"{final_wc.stem.replace('_clipped', '')}.tif"
        )
        return final_wc.parent / f"{final_wc.stem.replace('_clipped', '')}.tif"
