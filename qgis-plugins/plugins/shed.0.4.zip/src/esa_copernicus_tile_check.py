import requests
import geopandas as gpd
import math
from shapely.geometry import Point, Polygon


def round_down_absolute(x):
    return int(math.copysign(math.floor(abs(x)), x))


def round_up_absolute(x):
    return int(math.copysign(math.ceil(abs(x)), x))


def get_copernicus_tiles(geodataframe: gpd.GeoDataFrame, resolution: int):
    if geodataframe.crs != 4326:
        geodataframe = geodataframe.to_crs(epsg=4326)

    minx, miny, maxx, maxy = geodataframe.total_bounds

    bounds = {
        "minx": round_down_absolute(minx) if minx >= 0 else round_up_absolute(minx),
        "maxx": round_up_absolute(maxx) if maxx >= 0 else round_down_absolute(maxx),
        "miny": round_down_absolute(miny) if miny >= 0 else round_up_absolute(miny),
        "maxy": round_up_absolute(maxy) if maxy >= 0 else round_down_absolute(maxy),
    }

    # bounds = {
    #     "minx": math.floor(minx),
    #     "maxx": math.floor(maxx) + 1,
    #     "miny": math.floor(miny),
    #     "maxy": math.floor(maxy) + 1,
    # }


    x_tiles = [t for t in range(bounds["minx"], bounds["maxx"]+1)]
    y_tiles = [t for t in range(bounds["miny"], bounds["maxy"]+1)]

    tile_keys = []

    tile_list_inventory = (
        rf"https://copernicus-dem-{resolution}m.s3.amazonaws.com/tileList.txt"
    )

    tile_list_request = requests.get(tile_list_inventory)
    all_tiles = tile_list_request.text.split("\r\n")

    unary_target_bounds = geodataframe.union_all()

    target_tiles = []

    for x in x_tiles:
        for y in y_tiles:
            if x < 0:
                e_ind = "W"
            else:
                e_ind = "E"
            if y < 0:
                n_ind = "S"
            else:
                n_ind = "N"
            northing = str(abs(y)).zfill(2)
            easting = str(abs(x)).zfill(3)

            tile_key = f"Copernicus_DSM_COG_{int(resolution / 3)}_{n_ind}{northing}_00_{e_ind}{easting}_00_DEM/Copernicus_DSM_COG_{int(resolution / 3)}_{n_ind}{northing}_00_{e_ind}{easting}_00_DEM.tif"

            tile_name = f"Copernicus_DSM_COG_{int(resolution / 3)}_{n_ind}{northing}_00_{e_ind}{easting}_00_DEM"

            if tile_name in all_tiles:
                tile_geom = Polygon(
                    [Point(x, y + 1), Point(x + 1, y + 1), Point(x + 1, y), Point(x, y)]
                )
                if tile_geom.intersects(unary_target_bounds):
                    tile_keys.append(tile_key)
                    target_tiles.append(tile_geom)

            else:
                pass
    return tile_keys
