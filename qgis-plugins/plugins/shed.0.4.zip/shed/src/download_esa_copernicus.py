import geopandas as gpd
import requests
from pathlib import Path
import os
from requests.adapters import HTTPAdapter, Retry
from concurrent.futures import ThreadPoolExecutor
from shed.src.esa_copernicus_tile_check import (
    get_copernicus_tiles,
)
from shed.src.utils.postprocess_raster import (
    postprocess_raster,
)


class DownloadEsaCopernicus:
    def __init__(
        self,
        target_folder,
        shape,
        target_epsg,
        resolution: int = 90,
        parallel_downloads: int = 6,
    ):
        self.resolution = resolution
        self.amazon_s3_prefix = f"https://copernicus-dem-{resolution}m.s3.amazonaws.com"
        self.shape = shape

        self.target_folder = target_folder
        self.target_epsg = target_epsg

        self.download_dir = Path(self.target_folder) / f"Copernicus_{self.resolution}m"
        self.download_dir.mkdir(exist_ok=True, parents=True)

        self.parallel_downloads = parallel_downloads

    def esa_request(
        self,
        tile,
    ):
        url = f"{self.amazon_s3_prefix}/{tile}"
        out_fn = (
            self.download_dir / f"{tile.split(r'/')[-1].split('.')[0]}_EPSG_4326.tif"
        )

        if not out_fn.exists():
            session = requests.Session()
            retries = Retry(
                total=5, backoff_factor=0.5, status_forcelist=[414, 500, 502, 503, 504]
            )
            session.mount("https://", HTTPAdapter(max_retries=retries))
            r = session.get(url, allow_redirects=True)

            with open(out_fn, "wb") as f:
                f.write(r.content)

    def download_tiles(self) -> Path:
        os.makedirs(self.download_dir, exist_ok=True)

        tiles_to_download = get_copernicus_tiles(
            geodataframe=self.shape, resolution=self.resolution
        )

        with ThreadPoolExecutor(max_workers=self.parallel_downloads) as executor:
            executor.map(self.esa_request, tiles_to_download)

        raster_files = list(self.download_dir.glob("*.tif"))

        output_path = (
            self.download_dir
            / f"{self.target_folder.stem}_ESA_Copernicus_EPSG_{self.target_epsg}.tif"
        )

        self.shape_dst_crs = self.shape.to_crs(epsg=self.target_epsg)
        final_dem = postprocess_raster(
            target_crs=self.target_epsg,
            raster_paths=raster_files,
            output_filename=output_path,
            clipping_polygon=self.shape_dst_crs.geometry.iloc[0],
            target_res=self.resolution,
            resample_algorithm="bilinear",
        )

        # merge_and_reproject_rasters(
        #     target_crs=self.target_epsg,
        #     raster_paths=raster_files,
        #     output_filename=output_path,
        #     target_res=self.resolution,
        #     resample_algorithm="bilinear",
        # )

        # final_dem = crop_raster_on_shape(
        #     input_raster=output_path, geom=self.shape, target_crs=self.target_epsg
        # )

        # print("ESA Copernicus - Removing intermediary files...")
        [f.unlink() for f in self.download_dir.glob("*.tif") if f != final_dem]

        final_dem.rename(
            final_dem.parent
            / f"{final_dem.stem.replace('_clipped', f'_{self.resolution}m')}.tif"
        )

        return (
            final_dem.parent
            / f"{final_dem.stem.replace('_clipped', f'_{self.resolution}m')}.tif"
        )
