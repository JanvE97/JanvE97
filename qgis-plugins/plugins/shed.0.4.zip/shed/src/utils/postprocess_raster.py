from pathlib import Path
from osgeo import gdal
from shapely.geometry import Polygon


def postprocess_raster(
    target_crs: int,
    raster_paths: list,
    output_filename,
    target_res: int,
    clipping_polygon: Polygon,
    dst_nodata: int = -9999,
    resample_algorithm: str = "",
):
    gdal.DontUseExceptions()

    first_raster = raster_paths[0].as_posix()

    with gdal.Open(first_raster) as src:
        src_nodata = src.GetRasterBand(1).GetNoDataValue()

    options = {
        "srcNodata": src_nodata,
        "dstNodata": dst_nodata,
        "format": "GTiff",
        "cutlineDSName": clipping_polygon,
        "cropToCutline": True,
        "creationOptions": ["COMPRESS=DEFLATE", "BIGTIFF=YES", "TILED=YES"],
    }

    if target_crs != 4326:
        options["xRes"] = target_res
        options["yRes"] = target_res
        options["targetAlignedPixels"] = True
        options["dstSRS"] = f"EPSG:{target_crs}"

    if resample_algorithm != "":
        options["resampleAlg"] = resample_algorithm
    else:
        pass

    gdal.Warp(
        output_filename.as_posix(), [f.as_posix() for f in raster_paths], **options
    )
    return output_filename
