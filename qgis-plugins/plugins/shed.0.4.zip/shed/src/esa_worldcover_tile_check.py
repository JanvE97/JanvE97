import geopandas as gpd


def esa_check_tiles_to_download(shape_wkt_epsg4326):
    amazon_s3_prefix = "https://esa-worldcover.s3.eu-central-1.amazonaws.com"

    grid = gpd.read_file(
        f"{amazon_s3_prefix}/v100/2020/esa_worldcover_2020_grid.geojson"
    )
    grid = grid.set_crs(epsg=4326, allow_override=True)

    shape = gpd.GeoSeries.from_wkt([shape_wkt_epsg4326])
    grid_intersection = grid.loc[grid.intersects(shape.geometry.iloc[0])]

    if grid_intersection is not None and len(grid_intersection) > 0:
        tiles_to_download = grid_intersection["ll_tile"].tolist()
    else:
        tiles_to_download = None
    return tiles_to_download
