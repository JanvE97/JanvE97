from PyQt5.QtCore import pyqtSignal
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)
from qgis.core import QgsMessageLog
from shed.src.download_esa_copernicus import DownloadEsaCopernicus

# from shed.scripts.raster_downloaders.download_copernicus_raster import (
#     DownloadCopernicus,
# )
# from shed.scripts.utils.raster_utils.get_raster_crs import get_raster_crs
# from shed.scripts.utils.raster_utils.merge_and_reproject_rasters import (
#     merge_and_reproject_rasters,
# )
# from shed.scripts.utils.raster_utils.crop_raster import (
#     crop_raster,
# )
from pathlib import Path
import geopandas as gpd


MESSAGE_CATEGORY = "CopernicusDownloader"


class CopernicusDownloadTask(QgsTask):
    get_raster_path = pyqtSignal(str)
    isFinished = pyqtSignal(bool)

    def __init__(
        self,
        shape,
        target_folder,
        target_epsg,
        resolution: int = 90,
        parallel_downloads: int = 6,
        description: str = "Download Copernicus",
    ):
        super().__init__(description, QgsTask.CanCancel)
        self.shape = shape
        self.target_folder = target_folder
        self.target_epsg = target_epsg
        self.resolution = resolution
        self.parallel_downloads = parallel_downloads

        self.output_raster_path = None

    def run(self):
        """Here you implement your heavy lifting.
        Should periodically test for isCanceled() to gracefully
        abort.
        This method MUST return True or False.
        Raising exceptions will crash QGIS, so we handle them
        internally and raise them in self.finished
        """
        try:
            QgsMessageLog.logMessage(
                "{name} - Initiate Copernicus Downloader tool".format(
                    name=self.description()
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            download_copernicus = DownloadEsaCopernicus(
                target_folder=self.target_folder,
                shape=self.shape,
                target_epsg=self.target_epsg,
                resolution=self.resolution,
                parallel_downloads=self.parallel_downloads,
            )

            QgsMessageLog.logMessage(
                "{name} - Downloading rasters".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            self.output_raster_path = download_copernicus.download_tiles()
            return True

        except Exception as e:
            self.exception = e
            self.cancel()
            return False

    def finished(self, result):
        """
        This function is automatically called when the task has
        completed (successfully or not).
        You implement finished() to do whatever follow-up stuff
        should happen after the task is complete.
        finished is always called from the main thread, so it's safe
        to do GUI operations and raise Python exceptions here.
        result is the return value from self.run.
        """

        if result:
            self.get_raster_path.emit(str(self.output_raster_path.as_posix()))
            self.isFinished.emit(True)
            QgsMessageLog.logMessage(
                "{name} completed".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Success,
            )
        else:
            if self.exception is None:
                QgsMessageLog.logMessage(
                    "{name} not successful but without "
                    "exception (probably the task was manually "
                    "canceled by the user)".format(name=self.description()),
                    MESSAGE_CATEGORY,
                    Qgis.Warning,
                )
            else:
                QgsMessageLog.logMessage(
                    "{name} Exception: {exception}".format(
                        name=self.description(), exception=self.exception
                    ),
                    MESSAGE_CATEGORY,
                    Qgis.Critical,
                )
                raise self.exception

    def cancel(self):
        QgsMessageLog.logMessage(
            'RandomTask "{name}" was canceled'.format(name=self.description()),
            MESSAGE_CATEGORY,
            Qgis.Info,
        )
        super().cancel()
