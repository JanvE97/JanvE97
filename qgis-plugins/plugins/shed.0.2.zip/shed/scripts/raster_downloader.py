import requests
import tarfile
import geopandas as gpd
import math
from pathlib import Path
import os
import time
import datetime as dt
import rasterio
from rasterio.merge import merge
from rasterio.mask import mask
import xarray
import shutil
import rioxarray as rio
from osgeo import gdal, osr
# from PyQt5.QtCore import pyqtSignal, Qt
from qgis.core import (
  Qgis,
  QgsApplication,
  QgsMessageLog,
  QgsProcessingAlgRunnerTask,
  QgsProcessingContext,
  QgsProcessingFeedback,
  QgsProject,
  QgsTask,
  QgsTaskManager,
)
# from qgis.core import QgsMessageLog
# download copernicus dem GLO-30

MESSAGE_CATEGORY = 'RasterDownload'
    
def get_available_copernicus_dem_types():
    view_url = r'https://prism-dem-open.copernicus.eu/pd-desk-open-access/publicDemURLs'
    available_dems = requests.get(view_url, headers={'accept':'json'}).json()
    dem_urls = [list(entry.values())[0] for entry in available_dems]
    return dem_urls

def get_raster_crs(raster_path):
    input_raster = gdal.Open(raster_path)
    proj = osr.SpatialReference(wkt=input_raster.GetProjection())
    return f"EPSG:{proj.GetAttrValue('AUTHORITY',1)}"


class DownloadCopernicus:
    def __init__(self, target_folder, shape, download_dem_name):
        self.download_url = r'https://prism-dem-open.copernicus.eu/pd-desk-open-access/prismDownload'
        
        self.target_folder = Path(target_folder)
        self.shape=shape
        
        self.download_dem_name = download_dem_name
            
    @property
    def copernicus_dem_tag(self):
        return self.download_dem_name.replace("/", '__')
    
    @property
    def copernicus_dem_tile_format(self):
        if 'GLO-90' in self.download_dem_name:
            return "Copernicus_DSM_30_{northing}_00_{easting}_00"
        elif 'GLO-30' in self.download_dem_name:
            return "Copernicus_DSM_10_{northing}_00_{easting}_00"
        else:
            return None
        
    def get_coordinates_from_shape(self, name):
        minx, miny, maxx, maxy = self.shape.bounds
      
        minx_round = math.floor(minx)
        miny_round = math.floor(miny)
        
        maxx_round = math.ceil(maxx)
        maxy_round = math.ceil(maxy)
        
        tiles_to_download = []
        
        for lat in range(minx_round, maxx_round):
            for lon in range(miny_round, maxy_round):
                if lon < 0:
                    northing = f'S{str(-lon).zfill(2)}'
                else:
                    northing = f'N{str(lon).zfill(2)}'
                    
                if lat < 0:
                    easting = f'W{str(-lat).zfill(3)}'
                else:
                    easting = f'E{str(lat).zfill(3)}'  
    
                tiles_to_download.append(name.format(northing=northing, easting=easting))
        
        print(len(tiles_to_download))
        return tiles_to_download
    
    def download_rasters(self):
        # create_target_dir
        formatted_time = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        main_dir = self.target_folder / '_RAW'/ 'COPERNICUS_DEM'
        target_dir = self.target_folder / '_RAW'/ 'COPERNICUS_DEM' / 'SOURCE'
        os.makedirs(target_dir, exist_ok=True)
        
        tiles_to_download = self.get_coordinates_from_shape(name=self.copernicus_dem_tile_format)
        
        
        get_urls = [f'{self.download_url}/{self.copernicus_dem_tag}/{dem_name}.tar' for dem_name in tiles_to_download]
        
        for url in get_urls:
            filename = target_dir / url.split(r'/')[-1]
        
            r = requests.get(url, headers={'accept':'json'})
            
            with open(target_dir / filename, "wb") as file:
                file.write(r.content)
        
        extract_target_dir = Path(main_dir) / 'EXTRACT'
        os.makedirs(extract_target_dir, exist_ok=True)

        for tf in os.listdir(Path(main_dir) / "SOURCE"):
            try:            
                shutil.unpack_archive(Path(main_dir) / "SOURCE" / tf, extract_target_dir)
            except:
                pass
        return main_dir
    

class ProcessCopernicus:
    def __init__(self, download_folder, shape, dem_name):
        self.download_folder = download_folder
        self.dem_extract_folder = Path(download_folder) / 'EXTRACT'
        self.final_path = self.dem_extract_folder.parents[2]
        self.shape = shape
        self.temp_paths = []
        self.dem_name = dem_name
        
    def merge_rasters(self):
        dem_paths = []

        # remove old dems
        for old_dem in [x for x in os.listdir(self.download_folder) if 'merged_dem' in x]:
            os.remove(Path(self.download_folder) / old_dem)
        
        for extracted_folder in [x for x in os.listdir(self.dem_extract_folder) if 'tar' not in x]:
            dem_path = Path(self.download_folder) / 'EXTRACT' / extracted_folder / 'DEM' / os.listdir(Path(self.dem_extract_folder) / extracted_folder / 'DEM')[0]
            dem_paths.append(dem_path)

        dst_path = os.path.join(self.download_folder, 'merged_dem.tif')
        
        merge(datasets=dem_paths, dst_path=dst_path)
        self.temp_paths.append(dst_path)
        return dst_path
        
    def change_raster_nodata_value(self, input_raster):
        with rasterio.open(input_raster)  as src:
            profile = src.profile
            profile['nodata'] = -9999
            arr = src.read()
        
        dst_path = os.path.splitext(input_raster)[0] + '_nodata.tif'  #os.path.join(self.folder, 'merged_dem_nodata.tif')
        
        with rasterio.open(dst_path, 'w', **profile)  as dst:
            dst.write(arr)
        self.temp_paths.append(dst_path)
        return dst_path
        
    def crop_raster_on_shape(self, input_raster):
        with rasterio.open(input_raster)  as src:
            out_image, out_transform = mask(src, [self.shape], crop=True)
            out_meta = src.meta
        
        out_meta.update({"driver": "GTiff",
                 "height": out_image.shape[1],
                 "width": out_image.shape[2],
                 "transform": out_transform})

        
        dst_path = os.path.splitext(input_raster)[0] + '_clipped.tif'
        
        with rasterio.open(dst_path, "w", **out_meta) as dst:
            dst.write(out_image)
        self.temp_paths.append(dst_path)
        return dst_path
    
    def reproject_raster(self, input_raster, target_crs):
        current_raster_crs = get_raster_crs(raster_path=input_raster)
                
        dst_path = os.path.splitext(input_raster)[0] + '_reproj.tif'
        
        if target_crs != current_raster_crs:
            input_raster = gdal.Open(input_raster)
            warp = gdal.Warp(dst_path,input_raster,dstSRS=target_crs)
            warp = None
            input_raster = None
            self.temp_paths.append(dst_path)
            return dst_path

        else:
            self.temp_paths.append(input_raster)
            return input_raster
    
    def remove_wip_and_finalise(self, output_path):
        dst_path = self.final_path / f'{self.dem_name}.tif'
        
        shutil.copy(output_path, dst_path)
        self.temp_paths.append(output_path)
        
        for path in self.temp_paths:
            if os.path.exists(path):
                os.remove(path)
        return dst_path.as_posix()
        
    
class DownloadWorldCover:
    def __init__(self, target_folder, shape):
        self.amazon_s3_prefix = "https://esa-worldcover.s3.eu-central-1.amazonaws.com"
        self.shape = shape
        self.version = 'v200'
        self.year = 2021
        self.target_folder = target_folder
        
    def determine_tiles_to_download(self):
        # get tilegrid
        grid = gpd.read_file(f'{self.amazon_s3_prefix}/v100/2020/esa_worldcover_2020_grid.geojson')
        
        if self.shape.crs is not None:
            if self.shape.crs == grid.crs:
                grid_intersection = grid.loc[grid.intersects(self.shape.geometry.iloc[0])]
            else:
                self.shape = self.shape.to_crs(grid.crs)
                grid_intersection = grid.loc[grid.intersects(self.shape.geometry.iloc[0])]
        else:
            grid_intersection = None
        
        if grid_intersection is not None and len(grid_intersection) > 0:
            tiles_to_download = grid_intersection['ll_tile'].tolist()
        else:
            tiles_to_download = None
        return tiles_to_download
                
    def download_tiles(self, tiles_to_download):
        # create download dir
        download_dir = os.path.join(self.target_folder, '_RAW', f'ESA_WORLDCOVER_{self.year}')
        os.makedirs(download_dir, exist_ok=True)
        
        for tile in tiles_to_download:
            url = f"{self.amazon_s3_prefix}/{self.version}/{self.year}/map/ESA_WorldCover_10m_{self.year}_{self.version}_{tile}_Map.tif"
            out_fn = Path(download_dir) / f"ESA_WorldCover_10m_{self.year}_{self.version}_{tile}_Map.tif"

            r = requests.get(url, allow_redirects=True)
            with open(out_fn, 'wb') as f:
                f.write(r.content)
        return download_dir


class ProcessWorldCover:
    def __init__(self, download_folder, shape):
        self.download_folder = Path(download_folder)
        self.shape_gdf = shape
        self.shape = shape.to_crs(epsg=4326)['geometry'].iloc[0]
        self.temp_paths = []
        self.final_path = self.download_folder.parents[1]
        
    def merge_rasters(self):
        lc_paths = []

        # remove old files
        for old_lc in [x for x in os.listdir(self.download_folder) if 'esa_worldcover_2021' in x]:
            os.remove(Path(self.download_folder) / old_lc)
        
        lc_paths = [os.path.join(self.download_folder, x) for x in os.listdir(self.download_folder)]
        
        dst_path = os.path.join(self.download_folder, 'esa_worldcover_2021.tif')
        
        if len(lc_paths) > 1:
            merge(datasets=lc_paths, dst_path=dst_path)
        else:
            shutil.copy(lc_paths[0], dst_path)
        
        self.temp_paths.append(dst_path)
        return dst_path
            
    def crop_raster_on_shape(self, input_raster):
        with rasterio.open(input_raster)  as src:
            out_image, out_transform = mask(src, [self.shape_gdf.geometry.iloc[0]], crop=True)
            out_meta = src.meta
        
        out_meta.update({"driver": "GTiff",
                 "height": out_image.shape[1],
                 "width": out_image.shape[2],
                 "transform": out_transform})

        
        dst_path = os.path.splitext(input_raster)[0] + '_clipped.tif'
        
        with rasterio.open(dst_path, "w", **out_meta) as dst:
            dst.write(out_image)
        
        self.temp_paths.append(dst_path)
        return dst_path
    
    def reproject_raster(self, input_raster, target_crs):
        current_raster_crs = get_raster_crs(raster_path=input_raster)
                
        dst_path = os.path.splitext(input_raster)[0] + '_reproj.tif'
        
        if target_crs != current_raster_crs:
            input_raster = gdal.Open(input_raster)
            warp = gdal.Warp(dst_path,input_raster,dstSRS=target_crs)
            warp = None
            input_raster = None
            self.temp_paths.append(dst_path)
            return dst_path

        else:
            self.temp_paths.append(input_raster)
            return input_raster
        
    def remove_wip_and_finalise(self, output_path, lu_name='esa_worldcover'):
        dst_path = self.final_path / f'{lu_name}.tif'
        
        shutil.copy(output_path, dst_path)
        self.temp_paths.append(output_path)
        
        for path in self.temp_paths:
            if os.path.exists(path):
                os.remove(path)
        return dst_path.as_posix()
        
            
if __name__ == "__main__":
    shape = gpd.read_file(r'c:\Users\923265\Desktop\stevens_shape.gpkg')
    
    dwc = DownloadWorldCover(target_folder=r'd:\Documents\1_Scripting\0_QGIS_plugin\data\testoutput\test3', shape=shape)
    tiles_to_download = dwc.determine_tiles_to_download()

    dwc.download_tiles(tiles_to_download=tiles_to_download)


    