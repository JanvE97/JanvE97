from shed.scripts.utils.raster_utils.get_raster_crs import get_raster_crs
from osgeo import gdal
import os
from pathlib import Path


def reproject_raster(
    target_crs: int,
    input_raster_path: Path,
    output_raster_path: Path,
    target_res: int,
    src_nodata: int = 0,
    dst_nodata: int = 0,
):
    options = {
        "xRes": target_res,
        "yRes": target_res,
        "dstSRS": f"EPSG:{target_crs}",
        "srcNodata": src_nodata,
        "dstNodata": dst_nodata,
        "format": "GTiff",
        "targetAlignedPixels": True,
        "creationOptions": ["COMPRESS=DEFLATE", "BIGTIFF=YES", "TILED=YES"],
    }

    gdal.Warp(output_raster_path.as_posix(), input_raster_path.as_posix(), **options)
