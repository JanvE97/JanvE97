import whitebox_workflows
from pathlib import Path
import pandas as pd


def create_d8_raster(project):
    wbt = whitebox_workflows.WbEnvironment()
    wbt.verbose = False
    auto_compress = False
    
    if not pd.isnull(project.d8_pointer_file_location) and project.d8_pointer_file_location.exists():
        return True, "D8 pointer already exists"
    else:
        if not pd.isnull(project.filled_dem_file_location) and project.filled_dem_file_location.exists():
            filled_dem = wbt.read_raster(project.filled_dem_file_location.as_posix())
            d8_pointer = wbt.d8_pointer(filled_dem)

            d8_pointer_name = f"{Path(project.filled_dem_file_location).stem}_d8.tif"
            wbt.write_raster(
                d8_pointer,
                (Path(project.dem_dir) / d8_pointer_name).as_posix(),
                compress=auto_compress,
            )
            project.update_config(
                category="FILENAMES",
                parameter="d8_pointer_filename",
                value=(project.dem_dir / d8_pointer_name).name,
            )
            return True, "D8 pointer succesfully created"
        else:
            return False, "Filled DEM does not exist"