from osgeo import osr, gdal
from pathlib import Path


def get_raster_crs(raster_path: Path):
    input_raster = gdal.Open(raster_path.as_posix())
    proj = osr.SpatialReference(wkt=input_raster.GetProjection())
    del input_raster
    return f"EPSG:{proj.GetAttrValue('AUTHORITY',1)}"