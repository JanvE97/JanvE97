import requests
import math
from pathlib import Path
import os
import shutil
from osgeo import gdal, osr
from requests.adapters import HTTPAdapter, Retry
from concurrent.futures import ThreadPoolExecutor
from shed.scripts.utils.raster_utils.get_raster_crs import get_raster_crs
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)

MESSAGE_CATEGORY = "RasterDownload"


def get_available_copernicus_dem_types():
    view_url = r"https://prism-dem-open.copernicus.eu/pd-desk-open-access/publicDemURLs"
    available_dems = requests.get(view_url, headers={"accept": "json"}).json()
    dem_urls = [list(entry.values())[0] for entry in available_dems]
    return dem_urls


def request(tup):
    filename = tup[0] / tup[1].split(r"/")[-1]

    r = tup[2].get(tup[1], headers={"accept": "json"})

    with open(tup[0] / filename, "wb") as file:
        file.write(r.content)


class DownloadCopernicus:
    def __init__(self, target_folder, shape, download_dem_name):
        self.download_url = (
            r"https://prism-dem-open.copernicus.eu/pd-desk-open-access/prismDownload"
        )
        self.target_folder = Path(target_folder)
        self.shape = shape.iloc[0]
        self.download_dem_name = download_dem_name

    @property
    def copernicus_dem_tag(self):
        return self.download_dem_name.replace("/", "__")

    @property
    def copernicus_dem_tile_format(self):
        if "GLO-90" in self.download_dem_name:
            return "Copernicus_DSM_30_{northing}_00_{easting}_00"
        elif "GLO-30" in self.download_dem_name:
            return "Copernicus_DSM_10_{northing}_00_{easting}_00"
        else:
            return None

    def get_coordinates_from_shape(self, name):
        QgsMessageLog.logMessage(
            "Shape: {name}".format(name=self.shape),
            MESSAGE_CATEGORY,
            Qgis.Info,
        )
        QgsMessageLog.logMessage(
            "Bounds: {name}".format(name=self.shape.bounds),
            MESSAGE_CATEGORY,
            Qgis.Info,
        )
        minx, miny, maxx, maxy = self.shape.bounds

        minx_round = math.floor(minx)
        miny_round = math.floor(miny)

        maxx_round = math.ceil(maxx)
        maxy_round = math.ceil(maxy)

        tiles_to_download = []

        for lat in range(minx_round, maxx_round):
            for lon in range(miny_round, maxy_round):
                if lon < 0:
                    northing = f"S{str(-lon).zfill(2)}"
                else:
                    northing = f"N{str(lon).zfill(2)}"

                if lat < 0:
                    easting = f"W{str(-lat).zfill(3)}"
                else:
                    easting = f"E{str(lat).zfill(3)}"

                tiles_to_download.append(
                    name.format(northing=northing, easting=easting)
                )

        return tiles_to_download

    def download_rasters(self):
        main_dir = self.target_folder / "_RAW" / "COPERNICUS_DEM"
        target_dir = self.target_folder / "_RAW" / "COPERNICUS_DEM" / "SOURCE"
        target_dir.mkdir(exist_ok=True, parents=True)

        tiles_to_download = self.get_coordinates_from_shape(
            name=self.copernicus_dem_tile_format
        )

        get_urls = [
            f"{self.download_url}/{self.copernicus_dem_tag}/{dem_name}.tar"
            for dem_name in tiles_to_download
        ]

        session = requests.Session()
        retries = Retry(
            total=5, backoff_factor=0.5, status_forcelist=[414, 500, 502, 503, 504]
        )
        session.mount("https://", HTTPAdapter(max_retries=retries))

        MAX_THREADS = 3

        request_tuples = [(target_dir, url, session) for url in get_urls]
        with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
            executor.map(request, request_tuples)

        extract_target_dir = Path(main_dir) / "EXTRACT"
        extract_target_dir.mkdir(exist_ok=True, parents=True)

        for tf in (Path(main_dir) / "SOURCE").glob("*"):
            try:
                shutil.unpack_archive(
                    Path(main_dir) / "SOURCE" / tf.name, extract_target_dir
                )
            except Exception:
                pass
        return main_dir
