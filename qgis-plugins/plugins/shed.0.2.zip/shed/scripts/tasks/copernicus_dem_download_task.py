from PyQt5.QtCore import pyqtSignal
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)
from qgis.core import QgsMessageLog
from shed.scripts.raster_downloaders.download_copernicus_raster import (
    DownloadCopernicus,
)
from shed.scripts.utils.raster_utils.get_raster_crs import get_raster_crs
from shed.scripts.utils.raster_utils.merge_and_reproject_rasters import (
    merge_and_reproject_rasters,
)
from shed.scripts.utils.raster_utils.crop_raster import (
    crop_raster,
)
from pathlib import Path
import geopandas as gpd

MESSAGE_CATEGORY = "RasterDownload"


class CopernicusDemDownloadTask(QgsTask):
    get_raster_path = pyqtSignal(str)
    isFinished = pyqtSignal(bool)

    def __init__(
        self,
        shape_wkt,
        shape_wkt_wgs84,
        dem_dir,
        crs,
        spatial_res,
        description,
        download_dem_name,
        dem_filename,
    ):
        super().__init__(description, QgsTask.CanCancel)
        self.total = 0
        self.exception = None
        self.dem_dir = dem_dir
        self.shape_wkt = shape_wkt
        self.shape_wkt_wgs84 = shape_wkt_wgs84
        self.crs = crs

        self.spatial_res = spatial_res
        self.shape = gpd.GeoSeries.from_wkt([self.shape_wkt], crs=self.crs)
        self.shape_wgs84 = gpd.GeoSeries.from_wkt(
            [self.shape_wkt_wgs84], crs="epsg:4326"
        )
        self.download_dem_name = download_dem_name
        self.dem_filename = dem_filename

    def run(self):
        """Here you implement your heavy lifting.
        Should periodically test for isCanceled() to gracefully
        abort.
        This method MUST return True or False.
        Raising exceptions will crash QGIS, so we handle them
        internally and raise them in self.finished
        """
        try:
            QgsMessageLog.logMessage(
                "{name} - Initiate Copernicus Downloader tool".format(
                    name=self.description()
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            dc = DownloadCopernicus(
                target_folder=self.dem_dir,
                shape=self.shape_wgs84,
                download_dem_name=self.download_dem_name,
            )

            QgsMessageLog.logMessage(
                "{name} - Downloading rasters".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )
            download_folder = dc.download_rasters()
            extract_folder = Path(download_folder) / "EXTRACT"

            extracted_dem_paths = [
                f / "DEM" / [x.name for x in (f / "DEM").glob("*")][0]
                for f in extract_folder.glob("*")
            ]

            dst_path = Path(download_folder) / "merged_dem.tif"

            QgsMessageLog.logMessage(
                "{name} - Merging and reprojecting...".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            merge_and_reproject_rasters(
                target_crs=int(self.crs.split(":")[-1]),
                raster_paths=extracted_dem_paths,
                output_filename=dst_path,
                target_res=self.spatial_res,
                src_nodata=None,
                dst_nodata=-9999,
            )

            QgsMessageLog.logMessage(
                "{name} - Cropping raster on shape".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            self.output_raster_path = (self.dem_dir / self.dem_filename).as_posix()

            crop_raster(
                input_raster=dst_path.as_posix(),
                output_raster=self.output_raster_path,
                clipping_shape=self.shape.geometry.iloc[0],
            )

            return True

        except Exception as e:
            self.exception = e
            self.cancel()
            return False

    def finished(self, result):
        """
        This function is automatically called when the task has
        completed (successfully or not).
        You implement finished() to do whatever follow-up stuff
        should happen after the task is complete.
        finished is always called from the main thread, so it's safe
        to do GUI operations and raise Python exceptions here.
        result is the return value from self.run.
        """

        if result:
            self.get_raster_path.emit(self.output_raster_path)
            self.isFinished.emit(True)
            QgsMessageLog.logMessage(
                "{name} completed".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Success,
            )
        else:
            if self.exception is None:
                QgsMessageLog.logMessage(
                    "{name} not successful but without "
                    "exception (probably the task was manually "
                    "canceled by the user)".format(name=self.description()),
                    MESSAGE_CATEGORY,
                    Qgis.Warning,
                )
            else:
                QgsMessageLog.logMessage(
                    "{name} Exception: {exception}".format(
                        name=self.description(), exception=self.exception
                    ),
                    MESSAGE_CATEGORY,
                    Qgis.Critical,
                )
                raise self.exception

    def cancel(self):
        QgsMessageLog.logMessage(
            'RandomTask "{name}" was canceled'.format(name=self.description()),
            MESSAGE_CATEGORY,
            Qgis.Info,
        )
        super().cancel()
