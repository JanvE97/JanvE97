from PyQt5.QtCore import pyqtSignal
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)
from qgis.core import QgsMessageLog
from shed.scripts.utils.raster_utils.fill_dem import fill_dem
from shed.scripts.utils.raster_utils.create_d8_raster import create_d8_raster
from shed.scripts.utils.raster_utils.create_flow_accumulation_raster import (
    create_flow_accumulation_raster,
)
from shed.scripts.utils.raster_utils.create_stream_network import create_stream_network

MESSAGE_CATEGORY = "RasterFilling"


class PrepareRasterTask(QgsTask):
    fillingStatus = pyqtSignal(bool, str)
    isFinished = pyqtSignal(bool)

    def __init__(self, project, description):
        super().__init__(description, QgsTask.CanCancel)
        self.exception = None
        self.project = project

    def run(self):
        """Here you implement your heavy lifting.
        Should periodically test for isCanceled() to gracefully
        abort.
        This method MUST return True or False.
        Raising exceptions will crash QGIS, so we handle them
        internally and raise them in self.finished
        """
        try:
            QgsMessageLog.logMessage(
                "{name} - Preparing Delineation Rasters".format(
                    name=self.description()
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )
            status = []

            fill_dem_status, fill_dem_log = fill_dem(project=self.project)
            status.append(fill_dem_status)

            QgsMessageLog.logMessage(
                "{name} - fill_dem - {log}".format(
                    name=self.description(), log=fill_dem_log
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )

            if all(status):
                create_d8_raster_status, create_d8_raster_log = create_d8_raster(
                    project=self.project
                )
                status.append(create_d8_raster_status)

                QgsMessageLog.logMessage(
                    "{name} - create_d8_raster - {log}".format(
                        name=self.description(), log=create_d8_raster_log
                    ),
                    MESSAGE_CATEGORY,
                    Qgis.Info,
                )

            if all(status):
                (
                    create_flow_accumulation_raster_status,
                    create_flow_accumulation_raster_log,
                ) = create_flow_accumulation_raster(project=self.project)
                status.append(create_flow_accumulation_raster_status)

                QgsMessageLog.logMessage(
                    "{name} - create_flow_accumulation_raster - {log}".format(
                        name=self.description(), log=create_flow_accumulation_raster_log
                    ),
                    MESSAGE_CATEGORY,
                    Qgis.Info,
                )

            if all(status):
                create_stream_network_status, create_stream_network_log = (
                    create_stream_network(project=self.project)
                )
                status.append(create_stream_network_status)

                QgsMessageLog.logMessage(
                    "{name} - create_stream_network - {log}".format(
                        name=self.description(), log=create_stream_network_log
                    ),
                    MESSAGE_CATEGORY,
                    Qgis.Info,
                )

            if all(status):
                self.fillingStatus.emit(
                    True, "All preparation files generated succesfully"
                )
            else:
                self.fillingStatus.emit(
                    False, "All preparation files not generated succesfully"
                )
            return True

        except Exception as e:
            self.exception = e
            self.cancel()
            return False

    def finished(self, result):
        """
        This function is automatically called when the task has
        completed (successfully or not).
        You implement finished() to do whatever follow-up stuff
        should happen after the task is complete.
        finished is always called from the main thread, so it's safe
        to do GUI operations and raise Python exceptions here.
        result is the return value from self.run.
        """

        if result:
            self.isFinished.emit(True)
            QgsMessageLog.logMessage(
                "{name} completed".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Success,
            )
        else:
            if self.exception is None:
                QgsMessageLog.logMessage(
                    "{name} not successful but without "
                    "exception (probably the task was manually "
                    "canceled by the user)".format(name=self.description()),
                    MESSAGE_CATEGORY,
                    Qgis.Warning,
                )
            else:
                QgsMessageLog.logMessage(
                    "{name} Exception: {exception}".format(
                        name=self.description(), exception=self.exception
                    ),
                    MESSAGE_CATEGORY,
                    Qgis.Critical,
                )
                raise self.exception

    def cancel(self):
        QgsMessageLog.logMessage(
            'RandomTask "{name}" was canceled'.format(name=self.description()),
            MESSAGE_CATEGORY,
            Qgis.Info,
        )
        super().cancel()
