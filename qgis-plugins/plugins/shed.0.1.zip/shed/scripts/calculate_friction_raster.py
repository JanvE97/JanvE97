import requests
import tarfile as tarf
import geopandas as gpd
import math
from pathlib import Path
import os
import pandas as pd
import time
import datetime as dt
import rasterio
from rasterio.merge import merge
from rasterio.mask import mask
import xarray
import rioxarray as rio
from osgeo import gdal, osr
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtWidgets import QTableWidgetItem
from qgis.core import (
  Qgis,
  QgsApplication,
  QgsMessageLog,
  QgsProcessingAlgRunnerTask,
  QgsProcessingContext,
  QgsProcessingFeedback,
  QgsProject,
  QgsTask,
  QgsTaskManager,
)

from ..ui.load_ui import TableView

from qgis.core import QgsMessageLog
# download copernicus dem GLO-30


class FrictionTableEditor:
    def __init__(self, friction_table_name, friction_table_dir):
        self.friction_table_dir = friction_table_dir
        self.friction_table_name = friction_table_name
        
        # initiate table widget
        self.table_dialog = TableView()
        self.table_dialog.SaveTable.clicked.connect(self.save_edits)

        self.table_data = self.load_selected_friction_table()
        self.table_dialog.tableWidget.setRowCount(len(self.table_data))
        self.table_dialog.tableWidget.setColumnCount(len(self.table_data.columns))
        self.table_dialog.tableWidget.setHorizontalHeaderLabels(
            self.table_data.columns.astype(str)
        )
        
        for x in range(len(self.table_data)):
            for y in range(len(self.table_data.columns)):
                item = QTableWidgetItem(str(self.table_data.iloc[x, y]))
                self.table_dialog.tableWidget.setItem(x, y, item)
        
    def load_selected_friction_table(self):
        friction_table = pd.read_csv(os.path.join(self.friction_table_dir, self.friction_table_name))
        return friction_table
    
    def save_edits(self):   
        if self.table_dialog.lineEdit.text() != '':    
            values = []
            
            for x in range(self.table_dialog.tableWidget.rowCount()):
                value_list = []
                
                for y in range(self.table_dialog.tableWidget.columnCount()):
                    item = self.table_dialog.tableWidget.item(x,y).text()
                    value_list.append(item)
                
                values.append(value_list)
            
            new_friction = pd.DataFrame(values, columns = self.table_data.columns) 
            if self.table_dialog.lineEdit.text() is 'default':
                pass
            else:
                new_friction.to_csv(os.path.join(self.friction_table_dir, f'{self.table_dialog.lineEdit.text()}.csv'), index=None)
            self.table_dialog.close()
            
    def show_table(self):
        self.table_dialog.show()
        result = self.table_dialog.exec_()
        

def open_friction_table(friction_table_info):
    friction_table_dir = friction_table_info[0]
    select_friction_table_widget = friction_table_info[1]
    
    if friction_table_info[1] in [None, '-']:
        pass
    else:
        friction_table_editor = FrictionTableEditor(friction_table_name=str(select_friction_table_widget.currentText()), friction_table_dir=friction_table_dir)
        result = friction_table_editor.show_table()
        
        if result is None: # whacky: just after dialog is closed
            select_friction_table_widget.clear()
            select_friction_table_widget.addItems(os.listdir(friction_table_dir))

    