import openeo
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)

MESSAGE_CATEGORY = "RasterDownload"


def get_available_cds_products():
    connection = openeo.connect("openeo.dataspace.copernicus.eu")
    products = connection.list_collection_ids()
    return products