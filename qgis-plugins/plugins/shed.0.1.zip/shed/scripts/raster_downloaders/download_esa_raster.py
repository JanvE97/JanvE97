import requests
import geopandas as gpd
from pathlib import Path
import os
from requests.adapters import HTTPAdapter, Retry
from concurrent.futures import ThreadPoolExecutor
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)


MESSAGE_CATEGORY = "RasterDownload"


class DownloadWorldCover:
    def __init__(self, target_folder, shape):
        self.amazon_s3_prefix = "https://esa-worldcover.s3.eu-central-1.amazonaws.com"
        self.shape = shape
        self.version = "v200"
        self.year = 2021
        self.target_folder = target_folder

        self.download_dir = (
            Path(self.target_folder) / "_RAW" / f"ESA_WORLDCOVER_{self.year}"
        )
        self.download_dir.mkdir(exist_ok=True, parents=True)

        self.session = requests.Session()
        retries = Retry(
            total=5, backoff_factor=0.5, status_forcelist=[414, 500, 502, 503, 504]
        )

        self.session.mount("https://", HTTPAdapter(max_retries=retries))

    def esa_request(
        self,
        tile,
    ):
        url = f"{self.amazon_s3_prefix}/{self.version}/{self.year}/map/ESA_WorldCover_10m_{self.year}_{self.version}_{tile}_Map.tif"
        out_fn = (
            self.download_dir
            / f"ESA_WorldCover_10m_{self.year}_{self.version}_{tile}_Map.tif"
        )

        r = self.session.get(url, allow_redirects=True)
        with open(out_fn, "wb") as f:
            f.write(r.content)

    def download_tiles(self, tiles_to_download):
        # create download dir

        os.makedirs(self.download_dir, exist_ok=True)

        MAX_THREADS = 3

        with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
            executor.map(self.esa_request, tiles_to_download)
        return self.download_dir
