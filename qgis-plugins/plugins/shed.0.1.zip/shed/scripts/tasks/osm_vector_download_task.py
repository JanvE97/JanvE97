from PyQt5.QtCore import pyqtSignal
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)

# from shed.scripts.vector_downloaders.download_osm_data import (
#     download_osm_data,
# )
import osmnx as ox
from pathlib import Path
import geopandas as gpd
import time

MESSAGE_CATEGORY = "OsmVectorDownload"

OSM_BUILDINGS_STYLING = (
    Path(__file__).parents[2] / "stylings" / "osm_buildings.qml"
).as_posix()
OSM_LANDUSE_STYLING = (
    Path(__file__).parents[2] / "stylings" / "osm_landuse.qml"
).as_posix()
OSM_ROADS_STYLING = (
    Path(__file__).parents[2] / "stylings" / "osm_roads.qml"
).as_posix()


class OsmVectorDownloadTask(QgsTask):
    isFinished = pyqtSignal(bool)

    def __init__(
        self, description, shape_wkt_wgs84, tags, output_path, name, layer_manager
    ):
        super().__init__(description, QgsTask.CanCancel)
        self.exception = None
        self.shape_wgs84 = gpd.GeoSeries.from_wkt([shape_wkt_wgs84], crs="epsg:4326")
        self.tags = tags
        self.output_path = output_path
        self.name = name
        self.layer_manager = layer_manager

    def run(self):
        """Here you implement your heavy lifting.
        Should periodically test for isCanceled() to gracefully
        abort.
        This method MUST return True or False.
        Raising exceptions will crash QGIS, so we handle them
        internally and raise them in self.finished
        """
        try:
            osm_features = ox.features.features_from_polygon(
                polygon=self.shape_wgs84.geometry.iloc[0], tags=self.tags
            )
            if self.name == "OSM Landuse":
                osm_features = osm_features.loc[osm_features.geom_type == "Polygon"]

            elif self.name == "OSM Roads":
                osm_features = osm_features.loc[osm_features.geom_type == "LineString"]

            elif self.name == "OSM Buildings":
                osm_features = osm_features.loc[osm_features.geom_type == "Polygon"]

            osm_features.to_file(self.output_path / f"{self.name}.gpkg")
            return True

        except Exception as e:
            self.exception = e
            self.cancel()
            return False

    def finished(self, result):
        """
        This function is automatically called when the task has
        completed (successfully or not).
        You implement finished() to do whatever follow-up stuff
        should happen after the task is complete.
        finished is always called from the main thread, so it's safe
        to do GUI operations and raise Python exceptions here.
        result is the return value from self.run.
        """

        if result:
            self.isFinished.emit(True)
            #
            QgsMessageLog.logMessage(
                "{name} completed".format(name=self.description()),
                MESSAGE_CATEGORY,
                Qgis.Success,
            )
            if self.name == "OSM Landuse":
                style_file = OSM_LANDUSE_STYLING
            elif self.name == "OSM Roads":
                style_file = OSM_ROADS_STYLING
            elif self.name == "OSM Buildings":
                style_file = OSM_BUILDINGS_STYLING
            else:
                pass

            self.layer_manager.add_vector_layer_to_group(
                title=self.name,
                file_location=(self.output_path / f"{self.name}.gpkg").as_posix(),
                styling_file=style_file,
                zoom=False,
                insert_pos=1,
            )

        else:
            if self.exception is None:
                QgsMessageLog.logMessage(
                    "{name} not successful but without "
                    "exception (probably the task was manually "
                    "canceled by the user)".format(name=self.description()),
                    MESSAGE_CATEGORY,
                    Qgis.Warning,
                )
            else:
                QgsMessageLog.logMessage(
                    "{name} Exception: {exception}".format(
                        name=self.description(), exception=self.exception
                    ),
                    MESSAGE_CATEGORY,
                    Qgis.Critical,
                )
                raise self.exception

    def cancel(self):
        QgsMessageLog.logMessage(
            'RandomTask "{name}" was canceled'.format(name=self.description()),
            MESSAGE_CATEGORY,
            Qgis.Info,
        )
        super().cancel()


# class OsmVectorDownloadTask(QgsTask):
#     isFinished = pyqtSignal(bool)
#     emitDataFrames = pyqtSignal(list)

#     def __init__(self, crs, description, shape, output_folder):
#         super().__init__(description, QgsTask.CanCancel)
#         self.exception = None
#         self.crs = crs
#         self.shape = shape
#         self.output_folder = output_folder

#     def run(self):
#         """Here you implement your heavy lifting.
#         Should periodically test for isCanceled() to gracefully
#         abort.
#         This method MUST return True or False.
#         Raising exceptions will crash QGIS, so we handle them
#         internally and raise them in self.finished
#         """
#         try:
#             self.osm_landuse = ox.features.features_from_polygon(
#                 polygon=self.shape, tags={"landuse": True}
#             )

#             self.osm_landuse = self.osm_landuse.loc[self.osm_landuse.geometry.geom_type == "Polygon"]

#             self.osm_buildings = ox.features.features_from_polygon(
#                 polygon=self.shape, tags={"building": True}
#             )
#             self.osm_buildings = self.osm_buildings[["amenity", "name", "geometry"]]
#             self.osm_buildings = self.osm_buildings.loc[self.osm_buildings.geometry.geom_type == "Polygon"]

#             self.osm_roads = ox.features.features_from_polygon(
#                 polygon=self.shape, tags={"highway": True}
#             )

#             self.osm_roads = self.osm_roads.loc[self.osm_roads.geometry.geom_type == "LineString"]
#             self.osm_roads = self.osm_roads[["name", "highway", "surface", "geometry"]]

#             self.osm_landuse.to_file(self.output_folder / "OSM Landuse.gpkg")
#             self.osm_buildings.to_file(self.output_folder / "OSM Buildings.gpkg")
#             self.osm_roads.to_file(self.output_folder / "OSM Roads.gpkg")
#             return True

#         except Exception as e:
#             self.exception = e
#             self.cancel()
#             return False

#     def finished(self, result):
#         """
#         This function is automatically called when the task has
#         completed (successfully or not).
#         You implement finished() to do whatever follow-up stuff
#         should happen after the task is complete.
#         finished is always called from the main thread, so it's safe
#         to do GUI operations and raise Python exceptions here.
#         result is the return value from self.run.
#         """

#         if result:
#             self.isFinished.emit(True)
#             #self.emitDataFrames.emit([True])
#             QgsMessageLog.logMessage(
#                 "{name} completed".format(name=self.description()),
#                 MESSAGE_CATEGORY,
#                 Qgis.Success,
#             )
#         else:
#             if self.exception is None:
#                 QgsMessageLog.logMessage(
#                     "{name} not successful but without "
#                     "exception (probably the task was manually "
#                     "canceled by the user)".format(name=self.description()),
#                     MESSAGE_CATEGORY,
#                     Qgis.Warning,
#                 )
#             else:
#                 QgsMessageLog.logMessage(
#                     "{name} Exception: {exception}".format(
#                         name=self.description(), exception=self.exception
#                     ),
#                     MESSAGE_CATEGORY,
#                     Qgis.Critical,
#                 )
#                 raise self.exception

#     def cancel(self):
#         QgsMessageLog.logMessage(
#             'RandomTask "{name}" was canceled'.format(name=self.description()),
#             MESSAGE_CATEGORY,
#             Qgis.Info,
#         )
#         super().cancel()
