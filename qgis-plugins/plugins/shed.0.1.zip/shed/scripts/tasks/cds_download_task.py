from PyQt5.QtCore import pyqtSignal
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)
from qgis.core import QgsMessageLog
import openeo
from pathlib import Path
import geopandas as gpd


MESSAGE_CATEGORY = "Copernicus Data Space Download Task"


class CopernicusDataSpaceDownloadTask(QgsTask):
    isFinished = pyqtSignal(bool)
    get_raster_path = pyqtSignal(Path)

    def __init__(
        self,
        description: str,
        product: str,
        bbox_epsg4326: tuple,
        save_location: Path,
        target_crs: int,
        db_connection,
    ):
        super().__init__(description, QgsTask.CanCancel)
        self.total = 0
        self.exception = None
        self.product = product
        self.description = description
        self.bbox_epsg4326 = bbox_epsg4326
        self.save_location = save_location
        self.target_crs = target_crs
        self.shape_wgs84 = gpd.GeoSeries.from_wkt(
            [self.bbox_epsg4326], crs="epsg:4326"
        ).iloc[0].bounds
        self.db_connection = db_connection

    def run(self):
        """Here you implement your heavy lifting.
        Should periodically test for isCanceled() to gracefully
        abort.
        This method MUST return True or False.
        Raising exceptions will crash QGIS, so we handle them
        internally and raise them in self.finished
        """
        try:
            QgsMessageLog.logMessage(
                "{name} - Downloading {product} - bbox: {bbox}".format(
                    name=self.description, product=self.product, bbox=self.shape_wgs84
                ),
                MESSAGE_CATEGORY,
                Qgis.Info,
            )
            self.db_connection.load_collection(
                self.product,
                spatial_extent={"west": self.shape_wgs84[0], "south": self.shape_wgs84[1], "east": self.shape_wgs84[2], "north": self.shape_wgs84[3]},
            ).max_time().download(self.save_location)
            
            return True

        except Exception as e:
            self.exception = e
            self.cancel()
            return False

    def finished(self, result):
        """
        This function is automatically called when the task has
        completed (successfully or not).
        You implement finished() to do whatever follow-up stuff
        should happen after the task is complete.
        finished is always called from the main thread, so it's safe
        to do GUI operations and raise Python exceptions here.
        result is the return value from self.run.
        """

        if result:
            self.get_raster_path.emit(self.save_location)
            self.isFinished.emit(True)
            QgsMessageLog.logMessage(
                "{name} completed".format(name=self.description),
                MESSAGE_CATEGORY,
                Qgis.Success,
            )
        else:
            if self.exception is None:
                QgsMessageLog.logMessage(
                    "{name} not successful but without "
                    "exception (probably the task was manually "
                    "canceled by the user)".format(name=self.description),
                    MESSAGE_CATEGORY,
                    Qgis.Warning,
                )
            else:
                QgsMessageLog.logMessage(
                    "{name} Exception: {exception}".format(
                        name=self.description, exception=self.exception
                    ),
                    MESSAGE_CATEGORY,
                    Qgis.Critical,
                )
                raise self.exception

    def cancel(self):
        QgsMessageLog.logMessage(
            'RandomTask "{name}" was canceled'.format(name=self.description),
            MESSAGE_CATEGORY,
            Qgis.Info,
        )
        super().cancel()
