import requests
import tarfile as tarf
import geopandas as gpd
import math
from pathlib import Path
import os
import time
import datetime as dt
import rasterio
from rasterio.merge import merge
from rasterio.mask import mask
import xarray
import rioxarray as rio
from osgeo import gdal, osr
from PyQt5.QtCore import pyqtSignal, Qt
from qgis.core import (
  Qgis,
  QgsApplication,
  QgsMessageLog,
  QgsProcessingAlgRunnerTask,
  QgsProcessingContext,
  QgsProcessingFeedback,
  QgsProject,
  QgsTask,
  QgsTaskManager,
)
from qgis.core import QgsMessageLog


MESSAGE_CATEGORY = 'RasterDownload'
    
