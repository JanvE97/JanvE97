from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.core import (
    QgsGeometry,
    QgsProject,
    QgsMeshDatasetIndex,
    QgsPoint,
    QgsPointXY,
    QgsWkbTypes,
    QgsLayerTreeLayer,
    QgsRasterLayer,
    QgsVectorLayer,
)
from qgis.gui import *
from qgis.utils import iface

from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.core import QgsWkbTypes
from PyQt5.QtCore import pyqtSignal, Qt
from PyQt5.QtGui import QKeySequence, QColor


class LayerManager:
    def __init__(self, canvas, project_name):
        self.canvas = canvas
        self.project_name = project_name
        self.project_group = self.create_group_layer()

    def create_group_layer(self):
        if QgsProject.instance().layerTreeRoot().findGroup(self.project_name) is None:
            QgsProject.instance().layerTreeRoot().insertGroup(0, self.project_name)

        return QgsProject.instance().layerTreeRoot().findGroup(self.project_name)

    def add_raster_layer_to_group(
        self, title, file_location, styling_file, insert_pos=0
    ):
        layer_names = [
            layer.name()
            for layer in QgsProject.instance()
            .layerTreeRoot()
            .findGroup(self.project_name)
            .children()
        ]

        if title not in layer_names:
            layer = QgsRasterLayer(file_location, title)
            layer.loadNamedStyle(styling_file)
            QgsProject.instance().addMapLayer(layer, False)
            self.project_group.insertChildNode(insert_pos, QgsLayerTreeLayer(layer))
            layer.triggerRepaint()
            self.canvas.refresh()
        else:
            self.canvas.refresh()

    def add_vector_layer_to_group(
        self, title, file_location, styling_file=None, zoom=True, insert_pos=0
    ):
        layer_names = [
            layer.name()
            for layer in QgsProject.instance()
            .layerTreeRoot()
            .findGroup(self.project_name)
            .children()
        ]

        if title not in layer_names:
            layer = QgsVectorLayer(file_location, title, "ogr")

            if styling_file is not None:
                layer.loadNamedStyle(styling_file)
            QgsProject.instance().addMapLayer(layer, False)

            self.project_group.insertChildNode(insert_pos, QgsLayerTreeLayer(layer))

            layer.triggerRepaint()

            if zoom:
                extent = layer.extent()
                self.canvas.setExtent(extent)

            self.canvas.refresh()
        else:
            print("already present")
            # self.canvas.refresh()
