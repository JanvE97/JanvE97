from pathlib import Path
from osgeo import gdal


def merge_and_reproject_rasters(
    target_crs: int,
    raster_paths: list,
    output_filename,
    target_res: int,
    src_nodata: int = 0,
    dst_nodata: int = 0,
):
    options = {
        "xRes": target_res,
        "yRes": target_res,
        "dstSRS": f"EPSG:{target_crs}",
        "srcNodata": src_nodata,
        "dstNodata": dst_nodata,
        "format": "GTiff",
        "targetAlignedPixels": True,
        "creationOptions": ["COMPRESS=DEFLATE", "BIGTIFF=YES", "TILED=YES"],
    }

    gdal.Warp(
        output_filename.as_posix(), [f.as_posix() for f in raster_paths], **options
    )
