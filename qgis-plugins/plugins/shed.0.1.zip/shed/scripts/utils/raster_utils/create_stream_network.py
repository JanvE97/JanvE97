import whitebox_workflows
from pathlib import Path
import pandas as pd


def create_stream_network(project):
    wbt = whitebox_workflows.WbEnvironment()
    wbt.verbose = False
    
    if not pd.isnull(project.stream_network_file_location) and project.stream_network_file_location.exists():
        return True, "Stream network file already exists"
    else:
        if not pd.isnull(project.flow_accumulation_file_location) and project.flow_accumulation_file_location.exists():
            if not pd.isnull(project.d8_pointer_file_location) and project.d8_pointer_file_location.exists():
                d8_flowaccumulation = wbt.read_raster(project.flow_accumulation_file_location.as_posix())
            
                streams_raster = wbt.extract_streams(d8_flowaccumulation, threshold=0.6*1000000)
                
                streams_name = f"{Path(project.filled_dem_file_location)}_streams.shp"
                            
                del d8_flowaccumulation
                
                d8_pointer = wbt.read_raster(project.d8_pointer_file_location.as_posix())
                
                streams = wbt.raster_streams_to_vector(
                    streams_raster, d8_pointer
                )
                
                wbt.write_vector(streams, (project.dem_dir / streams_name).as_posix())
                    
                project.update_config(
                    category="FILENAMES",
                    parameter="stream_network_filename",
                    value=(project.dem_dir / streams_name).name,
                )
                return True, "Streams network succesfully created"
            else:
                return False, "d8 pointer file not found"
        else:
            return False, "Flow accumulation file not found"