import rasterio
from rasterio.mask import mask
from pathlib import Path


def crop_raster(input_raster: Path, output_raster: Path, clipping_shape):
    with rasterio.open(input_raster) as src:
        out_image, out_transform = mask(src, [clipping_shape], crop=True)
        out_meta = src.meta

        out_meta.update(
            {
                "driver": "GTiff",
                "height": out_image.shape[1],
                "width": out_image.shape[2],
                "transform": out_transform,
            }
        )
        
        with rasterio.open(output_raster, "w", **out_meta) as dst:
            dst.write(out_image)
