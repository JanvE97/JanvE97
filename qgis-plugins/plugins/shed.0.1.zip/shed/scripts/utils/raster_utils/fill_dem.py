import whitebox_workflows
from pathlib import Path
import pandas as pd


def fill_dem(project):
    wbt = whitebox_workflows.WbEnvironment()
    wbt.verbose = False
    auto_compress = False

    filled_dem_path = project.filled_dem_file_location
    
    if not pd.isnull(project.filled_dem_file_location) and filled_dem_path.exists():
        return True, "Filled DEM already exists"
    else:
        if not pd.isnull(project.dem_file_location) and project.dem_file_location.exists():
            dem = wbt.read_raster(project.dem_file_location.as_posix())
            filled_dem = wbt.fill_depressions_wang_and_liu(dem, fix_flats=True)
            filled_dem_name = f"{project.dem_file_location.stem}_filled.tif"
            wbt.write_raster(
                filled_dem,
                (project.dem_dir / filled_dem_name).as_posix(),
                compress=auto_compress,
            )
            project.update_config(
                category="FILENAMES",
                parameter="filled_dem_filename",
                value=(project.dem_dir / filled_dem_name).as_posix(),
            )
            return True, "Filled DEM succesfully created"
        else:
            return False, "DEM does not exist"