import whitebox_workflows
from shapely.geometry import Point
import geopandas as gpd
from shed.scripts.utils.raster_utils.polygonize import polygonize
import pandas as pd


def generate_upstream_watershed(project, geometry):
    wbt = whitebox_workflows.WbEnvironment()
    wbt.verbose = False

    watershed_file = project.watershed_dir / "watersheds.gpkg"
    pour_point_file = project.watershed_dir / "pour_points.gpkg"

    if (
        not pd.isnull(project.d8_pointer_file_location)
        and project.d8_pointer_file_location.exists()
    ):
        pour_point = gpd.GeoDataFrame(
            data={
                "name": ["pour_point"],
                "geometry": [Point(geometry.x(), geometry.y())],
            },
            index=[0],
            crs=project.crs,
        )
        pour_point.to_file(project.watershed_dir / "pour_point.shp")

        d8_pointer = wbt.read_raster(project.d8_pointer_file_location.as_posix())

        pour_points = wbt.read_vector(
            (project.watershed_dir / "pour_point.shp").as_posix()
        )

        watershed = wbt.watershed(d8_pointer, pour_points)

        del d8_pointer

        wbt.write_raster(
            watershed, (project.watershed_dir / "watershed.tif").as_posix()
        )

        polygonize(
            (project.watershed_dir / "watershed.tif").as_posix(),
            (project.watershed_dir / "watershed.shp").as_posix(),
            layer_name="watershed",
            epsg=project.crs,
        )

        watershed = gpd.read_file(project.watershed_dir / "watershed.shp")
        pour_point = gpd.read_file(project.watershed_dir / "pour_point.shp")

        [
            f.unlink()
            for f in project.watershed_dir.glob("*")
            if f.stem in ["watershed", "pour_point"]
        ]

        watershed = watershed.loc[watershed["value"] != -32768]

        if watershed_file.exists():
            current_watersheds = gpd.read_file(watershed_file)
        else:
            current_watersheds = None

        if pour_point_file.exists():
            current_pour_points = gpd.read_file(pour_point_file)
        else:
            current_pour_points = None

        if current_watersheds is not None and len(current_watersheds) > 0:
            watershed_id = int(max(current_watersheds["watershed_id"].tolist())) + 1
            pour_point["name"] = f"pour_point_{watershed_id}"
            watershed["name"] = f"watershed_{watershed_id}"

            updated_watersheds = pd.concat(
                [
                    current_watersheds,
                    pd.DataFrame(
                        data={
                            "watershed_id": [watershed_id],
                            "name": [watershed["name"].iloc[0]],
                            "geometry": [watershed["geometry"].iloc[0]],
                        }
                    ),
                ],
                axis=0,
            )
            updated_pour_points = pd.concat(
                [
                    current_pour_points,
                    pd.DataFrame(
                        data={
                            "watershed_id": [watershed_id],
                            "name": [pour_point["name"].iloc[0]],
                            "geometry": [pour_point["geometry"].iloc[0]],
                        }
                    ),
                ],
                axis=0,
            )

            updated_watersheds.to_file(watershed_file)
            updated_pour_points.to_file(pour_point_file)

        else:
            pour_point["name"] = "pour_point_0"
            watershed["name"] = "watershed_0"

            new_watersheds = gpd.GeoDataFrame(
                data={
                    "watershed_id": [0],
                    "name": [watershed["name"].iloc[0]],
                    "geometry": [watershed["geometry"].iloc[0]],
                }
            )
            new_pour_points = gpd.GeoDataFrame(
                data={
                    "watershed_id": [0],
                    "name": [pour_point["name"].iloc[0]],
                    "geometry": [pour_point["geometry"].iloc[0]],
                }
            )
            new_watersheds.to_file(watershed_file)
            new_pour_points.to_file(pour_point_file)
