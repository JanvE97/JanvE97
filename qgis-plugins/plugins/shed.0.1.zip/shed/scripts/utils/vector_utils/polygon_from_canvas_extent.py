from shapely.geometry import box
import geopandas as gpd
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)


def get_polygon_from_canvas_extent(project, layer_manager, canvas, bounds_styling):
    QgsMessageLog.logMessage(
        "{name} called".format(name="get_polygon_from_canvas_extent"),
        "RasterDownload",
        Qgis.Success,
    )
    # write current canvas crs to config.ini
    project.update_config(
        category="SETTINGS",
        parameter="crs",
        value=str(canvas.mapSettings().destinationCrs().authid()),
    )

    e = canvas.extent()

    geom = box(e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum())
    shape = gpd.GeoDataFrame(
        data={"ix": [0], "geometry": [geom]}, crs=project.crs
    )
    shape.to_file(project.data_dir / "shape.gpkg")

    # update reference
    project.update_config(
        category="SHAPE",
        parameter="shapefile_path",
        value=(project.data_dir / "shape.gpkg").as_posix(),
    )
    
    project.update_config(
        category="SHAPE",
        parameter="shapefile_wkt",
        value=shape.geometry.to_wkt().iloc[0],
    )
    
    shape_wgs84 = shape.to_crs(epsg=4326)
    
    project.update_config(
        category="SHAPE",
        parameter="shapefile_wkt_wgs84",
        value=shape_wgs84.geometry.to_wkt().iloc[0],
    )
    
    # show geometry on map
    layer_manager.add_vector_layer_to_group(
        title="Bounds",
        file_location=(project.data_dir / "shape.gpkg").as_posix(),
        styling_file=bounds_styling,
    )