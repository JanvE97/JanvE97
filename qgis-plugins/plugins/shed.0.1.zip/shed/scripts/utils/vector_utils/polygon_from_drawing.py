from qgis.gui import QgsRubberBand    
import shapely
import geopandas as gpd


def draw_polygon(canvas, drawing_tool):
    # remove current polygons
    [
        i.reset()
        for i in canvas.scene().items()
        if issubclass(type(i), QgsRubberBand)
    ]

    # set maptool
    current_map_tool = canvas.mapTool()
    canvas.unsetMapTool(current_map_tool)
    canvas.setMapTool(drawing_tool)


def confirm_poly_drawing(geom, drawing_tool, project, layer_manager, canvas, bounds_styling):
    # write current canvas crs to config.ini
    project.update_config(
        category="SETTINGS",
        parameter="crs",
        value=str(canvas.mapSettings().destinationCrs().authid()),
    )

    # unset custom map tool
    current_map_tool = canvas.mapTool()
    canvas.unsetMapTool(current_map_tool)
    drawing_tool.deactivate()
    # add polygon to canvas
    # add_polygon_to_canvas(canvas=self.canvas, polygon=geom)

    # write shape to gpkg in project dir
    input_geometry = shapely.wkt.loads(geom.asWkt()).geoms[0]
    gdf_input = gpd.GeoDataFrame(data={"geometry": [input_geometry]})
    gdf_input = gdf_input.set_crs(project.crs)
    gdf_input.to_file(project.data_dir / "shape.gpkg")

    layer_manager.add_vector_layer_to_group(
        title="Bounds",
        file_location=(project.data_dir / "shape.gpkg").as_posix(),
        styling_file=bounds_styling,
    )

    # update reference
    project.update_config(
        category="SHAPE",
        parameter="shapefile_path",
        value=(project.data_dir / "shape.gpkg").as_posix(),
    )