import configparser
from pathlib import Path
from shed.scripts.utils.auth_utils.auth_dialog import AuthDialog
import openeo
from shed.scripts.tasks.copernicus_auth_task import CopernicusAuthTask
from console import console
import io
import contextlib
from contextlib import redirect_stdout
import sys
from qgis.core import (
    Qgis,
    QgsMessageLog,
    QgsTask,
)
import tempfile
import time
import sys
from openeo.rest.auth.config import RefreshTokenStore


def reset_authentication():
    RefreshTokenStore().remove()


def authenticate(iface, connection, task_manager):
    task = CopernicusAuthTask(description="Authenticate", connection=connection)

    reply = AuthDialog(iface.mainWindow())
    reply.reset_auth.clicked.connect(reset_authentication)
    reply.show()
    
    if reply.exec_():
        console.show_console()
        task_manager.addTask(task)
