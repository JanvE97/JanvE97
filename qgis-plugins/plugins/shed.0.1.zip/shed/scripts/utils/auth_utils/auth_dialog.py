
from PyQt5.QtWidgets import QDialog, QDialogButtonBox, QVBoxLayout, QLabel, QLineEdit, QHBoxLayout, QWidget, QFormLayout, QGroupBox, QPushButton
from qgis.gui import QgsDialog


class AuthDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Copernicus DataSpace Authentication")

        QBtn = QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        
        # self.user_name_line_edit = QLineEdit()
        # self.password_line_edit = QLineEdit()
        
        self.buttonBox = QDialogButtonBox(QBtn)
        self.buttonBox.accepted.connect(self.accept)
        self.buttonBox.rejected.connect(self.reject)
        
        self.reset_auth = QPushButton("Reset Authentication")
        
        formGroupBox = QGroupBox("Authenticate")
        form_layout = QFormLayout()
        
        label = QLabel("To use this plugin, you must have an account on <a href='https://dataspace.copernicus.eu/'>Copernicus Dataspace Platform</a>.")
        
        label2 = QLabel("When you have an account, click OK to authenticate. ")
        
        label.setOpenExternalLinks(True)
        form_layout.addRow(label)
        form_layout.addRow(label2)
        form_layout.addRow(QLabel("If this is the first use of the plugin or if the last authentication has expired, you will be asked to authenticate again."))
        form_layout.addRow(QLabel("The console will open, copy the link that will be printed there and paste it in your browser."))
        form_layout.addRow(self.reset_auth)
        
        formGroupBox.setLayout(form_layout)
        
        self.layout = QVBoxLayout()
        self.layout.addWidget(formGroupBox)
        self.layout.addWidget(self.buttonBox)
        
        self.setLayout(self.layout)
        
    
