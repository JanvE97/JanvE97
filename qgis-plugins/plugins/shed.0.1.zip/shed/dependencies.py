from collections import namedtuple
from pathlib import Path
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets import QProgressBar
from PyQt5.QtWidgets import QProgressDialog
from PyQt5.QtWidgets import QMessageBox

import importlib
from importlib.metadata import PackageNotFoundError
import logging
import os
import pkg_resources
import platform
import shutil
import subprocess
import sys


Dependency = namedtuple("Dependency", ["name", "package", "constraint", "local"])

#: List of expected dependencies.
DEPENDENCIES = [
    Dependency("fiona", "fiona", "==1.10.1", False),
    Dependency("click", "click", "==8.1.7", False),
    Dependency("rasterio", "rasterio", "==1.4.2", False),
    Dependency("xarray", "xarray", "==2022.3.0", False),
    Dependency("rioxarray", "rioxarray", "==0.11.1", False),
    Dependency("affine", "Affine", "==2.4.0", False),
    Dependency("whitebox_workflows", "whitebox_workflows", "==1.3.1", False),
    Dependency("osmnx", "osmnx", "==1.9.4", False),
    Dependency("openeo", "openeo", "==0.36.0", False),
    Dependency("Deprecated", "Deprecated", "==1.2.15", False),
    Dependency("pystac", "pystac", "==1.11.0", False),
    Dependency("ipython", "ipython", "==8.29.0", False),
]            

INTERESTING_IMPORTS = ["osgeo", "pip", "setuptools"]

OUR_DIR = Path(__file__).parent

logger = logging.getLogger(__name__)


def create_progress_dialog(progress, text):
    dialog = QProgressDialog()
    dialog.setWindowTitle("SHED install progress")
    dialog.setLabelText(text)
    dialog.setWindowFlags(Qt.WindowStaysOnTopHint)
    bar = QProgressBar(dialog)
    bar.setTextVisible(True)
    bar.setValue(progress)
    bar.setValue(0)
    bar.setMaximum(100)
    dialog.setBar(bar)
    dialog.setMinimumWidth(500)
    dialog.update()
    dialog.setCancelButton(None)
    dialog.show()
    return dialog, bar


def ensure_everything_installed():
    """Check if DEPENDENCIES are installed and install them if missing."""

    # If required, create deps folder and prepend to the path
    target_dir = _dependencies_target_dir(create=True)
    if str(target_dir) not in sys.path:
        print(f"Prepending {target_dir} to sys.path")
        sys.path.insert(0, str(target_dir))

    _refresh_python_import_mechanism()

    profile_python_names = [item.name for item in _dependencies_target_dir().iterdir()]
    print("Contents of our deps dir:\n    %s" % "\n    ".join(profile_python_names))

    print("sys.path:")
    for directory in sys.path:
        print("  - %s" % directory)

    _ensure_prerequisite_is_installed()

    missing = _check_presence(DEPENDENCIES)
    restart_required = False

    if missing:
        print("Missing dependencies:")
        for deps in missing:
            print(deps.name)

        try:
            _install_dependencies(missing, target_dir=target_dir)
        except RuntimeError as e:
            print(e)
            # In case some libraries are already imported, we cannot uninstall
            # because QGIS acquires a lock on dll/pyd-files. Therefore
            # we need to restart Qgis.
            restart_required = True
            pass

        if restart_required:
            if _is_windows():
                QMessageBox.information(
                    None, "SHED", "Please restart QGIS to finish the installation"
                )

        # Always update the import mechanism
        _refresh_python_import_mechanism()

    else:
        print("Dependencies up to date")


def _ensure_prerequisite_is_installed(prerequisite="pip"):
    """Check the basics: pip.
    People using OSGEO custom installs sometimes exclude those
    dependencies. Our installation scripts fail, then, because of the missing
    'pip'.
    """
    try:
        importlib.import_module(prerequisite)
    except Exception as e:
        msg = (
            "%s. 'pip', which we need, is missing. It is normally included with "
            "python. You are *probably* using a custom minimal OSGEO release. "
            "Please re-install with 'pip' included."
        ) % e
        print(msg)
        raise RuntimeError(msg)


def _dependencies_target_dir(our_dir=OUR_DIR, create=False) -> Path:
    """Return (and create) the desired deps folder
    This is the 'deps' subdirectory of the plugin home folder
    """
    target_dir = our_dir / "deps"
    if not target_dir.exists() and create:
        print(f"Creating target dir {target_dir}")
        target_dir.mkdir()

    return target_dir


def check_importability():
    """Check if the dependendies are importable and log the locations.
    If something is not importable, which should not happen, it raises an
    ImportError automatically. Which is exactly what we want, because we
    cannot continue.
    """
    packages = [dependency.package for dependency in DEPENDENCIES]
    packages += INTERESTING_IMPORTS
    logger.info("sys.path:\n    %s", "\n    ".join(sys.path))
    deps_in_target_dir = [item.name for item in _dependencies_target_dir().iterdir()]
    logger.info(
        "Contents of our dependency dir:\n    %s",
        "\n    ".join(deps_in_target_dir),
    )
    for package in packages:
        imported_package = importlib.import_module(package)
        logger.info(
            "Import '%s' found at \n    '%s'", package, imported_package.__file__
        )


def _uninstall_dependency(dependency):
    print("Trying to uninstalling dependency %s" % dependency.name)
    python_interpreter = _get_python_interpreter()
    startupinfo = None
    if _is_windows():
        startupinfo = subprocess.STARTUPINFO()
        # Prevents terminal screens from popping up
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    process = subprocess.Popen(
        [
            python_interpreter,
            "-m",
            "pip",
            "uninstall",
            "--yes",
            (dependency.name),
        ],
        universal_newlines=True,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        startupinfo=startupinfo,
    )
    # The input/output/error stream handling is a bit involved, but it is
    # necessary because of a python bug on windows 7, see
    # https://bugs.python.org/issue3905 .
    i, o, e = (process.stdin, process.stdout, process.stderr)
    i.close()
    result = o.read() + e.read()
    o.close()
    e.close()
    print(result)
    exit_code = process.wait()
    if exit_code:
        print("Uninstalling %s failed" % dependency.name)


def _install_dependencies(dependencies, target_dir):
    if not dependencies:
        return

    python_interpreter = _get_python_interpreter()
    base_command = [
        python_interpreter,
        "-m",
        "pip",
        "install",
        "--upgrade",
        "--no-deps",
        "--find-links",
        str(OUR_DIR / "external-dependencies"),
        "--extra-index-url",
        "https://pypi.org/",
    ]

    dialog = None
    bar = None
    startupinfo = None
    if _is_windows():
        dialog, bar = create_progress_dialog(0, f"Installing {dependencies[0].name}")
        QApplication.processEvents()
        startupinfo = subprocess.STARTUPINFO()
        # Prevents terminal screens from popping up
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

    for count, dependency in enumerate(dependencies):
        _uninstall_dependency(dependency)
        print("Installing '%s' into %s" % (dependency.name, target_dir))
        if dependency.name != "numpy":
            base_command = base_command + ["--target", str(target_dir)]
        if dependency.local:
            base_command = base_command + ["--no-index"]
        command = base_command + [dependency.name + dependency.constraint]
        print(command)
        if dialog:
            dialog.setLabelText(f"Installing {dependency.name}")
        create_progress_dialog(0, "voor subprocess")
        process = subprocess.Popen(
            command,
            universal_newlines=True,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            startupinfo=startupinfo,
        )

        # The input/output/error stream handling is a bit involved, but it is
        # necessary because of a python bug on windows 7, see
        # https://bugs.python.org/issue3905 .
        i, o, e = (process.stdin, process.stdout, process.stderr)
        i.close()
        result = o.read() + e.read()
        o.close()
        e.close()

        print(result)
        exit_code = process.wait()

        if exit_code:
            if dialog:
                dialog.close()
                QApplication.processEvents()
            raise RuntimeError(
                f"Installing {dependency.name} failed ({exit_code}) ({result})"
            )

        print("Installed %s into %s" % (dependency.name, target_dir))
        if dependency.package in sys.modules:
            print("Unloading old %s module" % dependency.package)
            del sys.modules[dependency.package]
            # check_importability() will be called soon, which will import them again.
            # By removing them from sys.modules, we prevent older versions from
            # sticking around.

        if bar:
            bar.setValue(int((count / len(dependencies)) * 100))
            bar.update()
            QApplication.processEvents()

    if dialog:
        dialog.close()


def _is_windows():
    """Return whether we are starting from QGIS on Windows."""
    executable = sys.executable
    _, filename = os.path.split(executable)
    if "python3" in filename.lower():
        return False
    elif "qgis" in filename.lower():
        if platform.system().lower() == "darwin":
            return False
        else:
            return True
    else:
        raise EnvironmentError("Unexpected value for sys.executable: %s" % executable)


def _get_python_interpreter():
    """Return the path to the python3 interpreter.
    Under linux sys.executable is set to the python3 interpreter used by Qgis.
    However, under Windows/Mac this is not the case and sys.executable refers to the
    Qgis start-up script.
    """
    interpreter = None
    executable = sys.executable
    directory, _ = os.path.split(executable)
    if _is_windows():
        interpreter = os.path.join(directory, "python3.exe")
    elif platform.system().lower() == "darwin":
        interpreter = os.path.join(directory, "bin", "python3")
    else:
        interpreter = executable

    assert os.path.exists(interpreter)  # safety check
    return interpreter


def _check_presence(dependencies):
    missing = []
    for i in dependencies:
        print(f"Checking presence of {i.name}{i.constraint}...")
        try:
            version = importlib.metadata.version((i.package))
            if version != i.constraint[2:]:
                print(
                    f"Dependency {i.name} has the wrong version",
                    f"({importlib.metadata.version((i.package))} != {i.constraint[2:]})",
                )
                missing.append(i)
        except PackageNotFoundError:
            print(f"Dependency {i.name} not found")
            missing.append(i)
    return missing


def _refresh_python_import_mechanism():
    """Refresh the import mechanism.
    This is required when deps are dynamically installed/removed. The modules
    'importlib' and 'pkg_resources' need to update their internal data structures.
    """
    # This function should be called if any modules are created/installed while your
    # program is running to guarantee all finders will notice the new module’s existence.
    importlib.invalidate_caches()
    importlib.reload(pkg_resources)
